<?php

/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 */

namespace App;

use Timber\Timber;

$templates = array('templates/archive.twig', 'templates/index.twig');

$title = 'Archive';
$context_data = ['title' => $title];

if (is_day()) {
	$title = 'Archive: ' . get_the_date('D M Y');
} elseif (is_month()) {
	$title = 'Archive: ' . get_the_date('M Y');
} elseif (is_year()) {
	$title = 'Archive: ' . get_the_date('Y');
} elseif (is_tag()) {
	$title = single_tag_title('', false);
} elseif (is_category()) {
	$title = single_cat_title('', false);
} elseif (is_tax()) {
	// Handle custom taxonomy archives
	$term = get_queried_object();
	$title = $term->name;
	$context_data['term'] = Timber::get_term($term);
	
	// Check if this taxonomy is associated with a specific post type
	$taxonomy = get_taxonomy($term->taxonomy);
	if ($taxonomy && !empty($taxonomy->object_type)) {
		$post_type = $taxonomy->object_type[0]; // Get the first associated post type
		array_unshift($templates, 'templates/archive-' . $post_type . '.twig');
	}
} elseif (is_post_type_archive()) {
	$title = post_type_archive_title('', false);
	array_unshift($templates, 'templates/archive-' . get_post_type() . '.twig');
}

$context_data['title'] = $title;
$context = Timber::context($context_data);

Timber::render($templates, $context);