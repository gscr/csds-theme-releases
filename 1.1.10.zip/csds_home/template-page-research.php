<?php
/**
 * Template Name: Research
 * Description: A Page Template for research that shows publications.
 */

namespace App;

use Timber\Timber;

$context = Timber::context();

// Query the custom post type 'publication'
$args = array(
    'post_type' => 'publication',
    'posts_per_page' => -1, 
    'meta_key' => 'year', 
    'orderby' => 'meta_value_num', 
    'order' => 'DESC', 
);
$publications = Timber::get_posts($args);

// Get the taxonomy terms for each publication
// foreach ($publications as $publication) {
//     $publication->terms = Timber::get_terms([
//         'taxonomy' => 'publication_type',
//         'object_ids' => $publication->ID,
//     ]);
// }

// $context['publications'] = $publications;
$grouped_publications = [];
foreach ($publications as $publication) {
    $terms = wp_get_post_terms($publication->ID, 'publication_type');
    foreach ($terms as $term) {
        if (!isset($grouped_publications[$term->slug])) {
            $grouped_publications[$term->slug] = [
                'term' => $term,
                'publications' => []
            ];
        }
        $grouped_publications[$term->slug]['publications'][] = $publication;
    }
}

$context['grouped_publications'] = $grouped_publications;

Timber::render('templates/page-research.twig', $context);
