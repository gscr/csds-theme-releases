<?php

acf_add_local_field_group([
    'key' => 'group_courses_search_block',
    'title' => 'Courses Search Block Settings',
    'fields' => [
        [
            'key' => 'field_courses_search_term',
            'label' => 'Search Courses',
            'name' => 'search_term',
            'type' => 'text',
            'instructions' => 'Enter keywords to filter courses by name, code, or description (leave empty to show all)',
            'required' => 0,
            'placeholder' => 'e.g. simulation, emergency, pediatric',
        ],
        [
            'key' => 'field_courses_filter_types',
            'label' => 'Filter by Course Type',
            'name' => 'filter_types',
            'type' => 'checkbox',
            'instructions' => 'Select which course types to include (leave empty for all types)',
            'choices' => [
                'online' => 'Online Courses',
                'f2f' => 'Face-to-face Courses',
                'blended' => 'Blended Courses',
            ],
            'layout' => 'vertical',
        ],
        [
            'key' => 'field_courses_sort_by',
            'label' => 'Sort Courses By',
            'name' => 'sort_by',
            'type' => 'select',
            'instructions' => 'Choose how to sort the displayed courses',
            'required' => 1,
            'choices' => [
                'default' => 'Default Order',
                'name' => 'Name (A-Z)',
                'name-desc' => 'Name (Z-A)',
                'duration' => 'Duration (Short to Long)',
                'duration-desc' => 'Duration (Long to Short)',
            ],
            'default_value' => 'default',
        ],
        [
            'key' => 'field_courses_default_display',
            'label' => 'Default Display Mode',
            'name' => 'default_display',
            'type' => 'select',
            'instructions' => 'What to show when no search is performed',
            'required' => 1,
            'choices' => [
                'featured' => 'Show featured courses',
                'recent' => 'Show recent courses', 
                'all' => 'Show all courses (filtered)',
            ],
            'default_value' => 'all',
        ],
        [
            'key' => 'field_courses_posts_per_page',
            'label' => 'Posts per Page',
            'name' => 'posts_per_page',
            'type' => 'number',
            'instructions' => 'Number of courses to display per page (pagination will be used for additional results)',
            'required' => 1,
            'default_value' => 12,
            'min' => 4,
            'max' => 24,
        ],
        [
            'key' => 'field_courses_no_results_message',
            'label' => 'No Results Message',
            'name' => 'no_results_message',
            'type' => 'textarea',
            'instructions' => 'Message to show when no courses are found',
            'required' => 0,
            'default_value' => 'No courses found matching your search criteria. Please try different keywords or adjust your filters.',
            'rows' => 3,
        ],
    ],
    'location' => [
        [
            [
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/courses-search-block',
            ]
        ]
    ],
    'menu_order' => 0,
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
]);
