<?php
/**
 * Template Name: Courses
 * Description: A Page Template for courses.
 * 
 * API DATA STRUCTURE DOCUMENTATION
 * ================================
 * 
 * The courses API returns an object with the following structure:
 * 
 * courses: {
 *   featuredCourses: Array of course objects
 *   upcomingCourses: Array of course objects  
 *   popularElearning: Array of course objects
 *   popularF2f: Array of course objects (Face-to-face)
 *   physioCourses: Array of course objects (physiotherapy)
 * }
 * 
 * COURSE OBJECT STRUCTURE:
 * ========================
 * 
 * Basic Course Information:
 * - courseID: int - Unique course identifier
 * - courseCode: string - Short course code (e.g. "TST", "BASIC Sim")
 * - courseName: string - Full course name
 * - courseDescription: string - HTML description of the course
 * - shortDescription: string - Plain text short description
 * - courseDuration: string - Duration value
 * - courseDurationMeasurement: string - "D" (days), "H" (hours)
 * - coursePoints: string|null - CPD/credit points information
 * - courseParticipants: string - Target audience description
 * - prerequisites: string - Prerequisites description
 * - prereading: string|null - Pre-reading requirements
 * 
 * Course Settings:
 * - isListed: int - 1 if publicly listed, 0 if not
 * - courseLimitMin: int - Minimum participants
 * - courseLimitMax: int - Maximum participants  
 * - frequency: string - How often course runs
 * - courseTypeID: int - 1=Face-to-face, 2=Online, 3=Blended
 * - isInviteOnly: int - 1 if invite only, 0 if open
 * - requiresApproval: int - 1 if requires approval, 0 if not
 * - isDeleted: int - 0 if active, 1 if deleted
 * 
 * Host Information:
 * - hostDetail: string - Host organization name
 * - hostContact: string - Contact information
 * 
 * Dates & Timestamps:
 * - courseLaunchDate: string - Date format "YYYY-MM-DD"
 * - createdTime: int|null - Unix timestamp in milliseconds
 * - modifiedTime: int|null - Unix timestamp in milliseconds
 * - listedStatusChangedTime: string|null - Date format "YYYY-MM-DD HH:MM:SS"
 * - listedStatusChangedByID: int|null - User ID who changed status
 * 
 * Resources & Media:
 * - flyerResourceID: int - ID for course flyer
 * - courseImageResourceID: int - ID for course image
 * - courseImageURL: string - Full URL to course image (S3 signed URL)
 * 
 * Course Materials:
 * - isSentPost: int - 1 if materials sent by post, 0 if not
 * - willReceivePost: string|null - Description of postal materials
 * - isDownloadAvailable: int - 1 if downloads available, 0 if not
 * - willReceiveDownload: string|null - Description of downloadable materials
 * 
 * E-Learning Specific:
 * - use_xml_menu: int - 1 if uses XML menu, 0 if not
 * - xml_menu_path: string|null - Path to XML menu file
 * - root_folder: string|null - Root folder for e-learning content
 * - module_nav_type: int - Navigation type for modules
 * - hosted: int - 1 if externally hosted, 0 if internal
 * - httpLink: string|null - External link for hosted courses
 * - expiryLengthMonths: int|null - Course access expiry in months
 * 
 * Certificates & Requirements:
 * - completionRequirements: string|null - Requirements for completion
 * - outcomeRequirements: int - 1 if outcome requirements exist, 0 if not
 * - showQuizOnCertificate: int - 1 if quiz shown on certificate, 0 if not
 * - showDirectorBio: int - 1 if director bio shown, 0 if not
 * 
 * Catering:
 * - cateringType: string|null - Description of catering provided
 * 
 * Metadata Object:
 * - metadata: {
 *     cateringTypeID: string|null - ID for catering type
 *     hasCertificate: string - "1" if has certificate, "0" if not
 *     courseDirectorID: int - ID of course director
 *     eLearningCourseID: int|null - Associated e-learning course ID
 *     certificateID: int|null - Certificate template ID
 *     certificateText: string|null - Custom certificate text
 *     standardTypeID: int - Standard/accreditation type
 *     courseAccumulative: string - Accumulative points/hours
 *     courseDomainID: int - Domain/category ID
 *     courseCat: int|null - Category ID
 *     isFacLF: int - Faculty flags (various)
 *     isFacSC: int
 *     isFacSE: int  
 *     isFacSF: int
 *     nurseMax: int - Maximum nurses allowed
 *     doctorMax: int - Maximum doctors allowed
 *   }
 * 
 * Course Type Object:
 * - type: {
 *     courseTypeName: string - "Face-to-face", "Online", "Blended"
 *   }
 * 
 * Status Changed By Object (if applicable):
 * - listedStatusChangedBy: {
 *     participantID: int - User ID
 *     participantTitle: string - Title (Mr, Ms, Dr, etc.)
 *     firstName: string - First name
 *     lastName: string - Last name
 *     participantEmail: string - Primary email
 *     secondaryEmail: string - Secondary email
 *     participantMobile: string - Mobile number
 *     validated: int - 1 if validated, 0 if not
 *     contactEmail: int - 1 if contact via email, 0 if not
 *     user_id: int - System user ID
 *     lastLogin: int - Unix timestamp in milliseconds
 *     createdTime: int - Unix timestamp in milliseconds
 *     isDeleted: int - 0 if active, 1 if deleted
 *     seenWelcomeModal: int - 1 if seen welcome, 0 if not
 *     courseBio: string|null - Course director bio
 *     fullName: string - Computed full name
 *     totalEquipmentCount: int - Equipment count
 *     pocketRoles: array - Array of roles
 *     postalLocationID: int - Location ID for postal address
 *     secondaryPostalLocationID: int|null - Secondary location ID
 *     metadata: { ... } - User metadata object
 *     location: { ... } - Location object with address details
 *   }
 * 
 * Computed/Display Fields:
 * - priceString: string - Formatted price (e.g. "From $150", "$0")
 * - courseClass: string - "f2f" (face-to-face), "online" 
 * - upcoming: string - Next course date info (e.g. "26 Aug + more dates", "Online")
 * - URL: string - Full URL to course page
 * - pocketID: int - Pocket/organization ID (typically 80 for CSDS)
 */

namespace App;

use Timber\Timber;

// Define API endpoints
$baseUrl = 'https://central.csds.qld.edu.au';
$requestUrl = $baseUrl . '/api/v2/courses/fetch-landing';
$requestUrlAll = $baseUrl . '/api/v2/courses'; // Base URL without parameters initially
$courseUrl = $baseUrl . '/central/courses';

// Fetch course data with error handling
try {
    $response = wp_remote_get($requestUrl, [
        'sslverify' => false,
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        throw new \Exception('Failed to fetch courses: ' . $response->get_error_message());
    }

    $responseCode = wp_remote_retrieve_response_code($response);
    if ($responseCode !== 200) {
        throw new \Exception('Invalid API response code: ' . $responseCode);
    }

    $fetchedJSON = wp_remote_retrieve_body($response);
    $courseData = json_decode($fetchedJSON, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new \Exception('Invalid JSON response: ' . json_last_error_msg());
    }
} catch (\Exception $e) {
    // Log error and set empty course data
    error_log($e->getMessage());
    $courseData = null;
}

// Function to fetch all courses with pagination handling
function fetchAllCourses($baseRequestUrl) {
    error_log('Starting fetchAllCourses function...');
    $allCourses = [];
    $page = 1;
    $limit = 20; // Use the known working limit
    $maxPages = 100; // Increase safety limit
    
    // Try different pagination patterns
    $paginationPatterns = [
        '?page={page}',
        '?page={page}&limit={limit}',
        '?page={page}&per_page={limit}',
        '?offset={offset}&limit={limit}',
        '?skip={offset}&take={limit}'
    ];
    
    foreach ($paginationPatterns as $pattern) {
        error_log('Trying pagination pattern: ' . $pattern);
        $allCourses = [];
        $page = 1;
        $foundNewData = false;
        
        do {
            $offset = ($page - 1) * $limit;
            $currentUrl = $baseRequestUrl . str_replace(
                ['{page}', '{limit}', '{offset}'],
                [$page, $limit, $offset],
                $pattern
            );
            
            error_log('Fetching page ' . $page . ' with URL: ' . $currentUrl);
            
            try {
                $response = wp_remote_get($currentUrl, [
                    'sslverify' => false,
                    'timeout' => 15,
                    'headers' => [
                        'Accept' => 'application/json',
                    ],
                ]);

                if (is_wp_error($response)) {
                    error_log('Failed to fetch courses page ' . $page . ': ' . $response->get_error_message());
                    break;
                }

                $responseCode = wp_remote_retrieve_response_code($response);
                if ($responseCode !== 200) {
                    error_log('Invalid API response code for courses page ' . $page . ': ' . $responseCode);
                    break;
                }

                $fetchedJSON = wp_remote_retrieve_body($response);
                $pageData = json_decode($fetchedJSON, true);
                
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('Invalid JSON response for courses page ' . $page . ': ' . json_last_error_msg());
                    break;
                }
                
                // If the response is an array, merge it
                if (is_array($pageData)) {
                    $pageCount = count($pageData);
                    error_log('Page ' . $page . ' returned ' . $pageCount . ' items');
                    
                    // Check if this is different data from page 1
                    if ($page === 1) {
                        $allCourses = $pageData;
                    } else {
                        // Check if we're getting new data or the same data repeated
                        $isNewData = false;
                        if (!empty($pageData) && !empty($allCourses)) {
                            // Compare first item IDs to see if data is different
                            $firstNewId = isset($pageData[0]['courseID']) ? $pageData[0]['courseID'] : null;
                            $existingIds = array_column($allCourses, 'courseID');
                            $isNewData = !in_array($firstNewId, $existingIds);
                        }
                        
                        if ($isNewData) {
                            $allCourses = array_merge($allCourses, $pageData);
                            $foundNewData = true;
                            error_log('Found new data on page ' . $page . '. Total items: ' . count($allCourses));
                        } else {
                            error_log('Page ' . $page . ' returned duplicate data, stopping pagination');
                            break;
                        }
                    }
                    
                    // If we got fewer items than expected, we've reached the end
                    if ($pageCount < $limit) {
                        error_log('Got fewer items than limit, reached end of data');
                        break;
                    }
                } else {
                    error_log('Unexpected response structure on page ' . $page . ': ' . gettype($pageData));
                    break;
                }
                
                $page++;
                
            } catch (\Exception $e) {
                error_log('Error fetching courses page ' . $page . ': ' . $e->getMessage());
                break;
            }
            
        } while ($page <= $maxPages);
        
        // If we found new data with this pattern, use it
        if ($foundNewData && count($allCourses) > 20) {
            error_log('Pagination pattern "' . $pattern . '" successful. Total items: ' . count($allCourses));
            return $allCourses;
        }
    }
    
    error_log('All pagination patterns failed. Returning ' . count($allCourses) . ' items');
    return $allCourses;
}

// Fetch all courses using pagination
try {
    $allCoursesData = fetchAllCourses($baseUrl . '/api/v2/courses');
    
    if (empty($allCoursesData)) {
        error_log('Failed to fetch courses via pagination, setting empty array');
        $allCoursesData = [];
    } else {
        error_log('Successfully fetched all courses. Total count: ' . count($allCoursesData));
    }
    
} catch (\Exception $e) {
    error_log('Error fetching all courses: ' . $e->getMessage());
    $allCoursesData = [];
}

// Handle URL parameters for filtering
$searchTerm = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$courseTypes = isset($_GET['course-type']) ? array_map('sanitize_text_field', $_GET['course-type']) : [];
$sortBy = isset($_GET['sort-by']) ? sanitize_text_field($_GET['sort-by']) : '';

// Initialize filtered courses as empty by default (show nothing until filters applied)
$filteredCourses = [];

// Apply filters if parameters exist
if (!empty($searchTerm) || !empty($courseTypes) || !empty($sortBy)) {
    // Start from all courses when filters are applied
    $filteredCourses = $allCoursesData;
    
    // Apply search filter
    if (!empty($searchTerm)) {
        $filteredCourses = array_filter($filteredCourses, function($course) use ($searchTerm) {
            $searchableText = strtolower(
                ($course['courseName'] ?? '') . ' ' .
                ($course['courseCode'] ?? '') . ' ' .
                ($course['courseDescription'] ?? '') . ' ' .
                ($course['shortDescription'] ?? '')
            );
            return strpos($searchableText, strtolower($searchTerm)) !== false;
        });
    }
    
    // Apply course type filter
    if (!empty($courseTypes)) {
        $filteredCourses = array_filter($filteredCourses, function($course) use ($courseTypes) {
            $isOnline = ($course['courseTypeID'] ?? 0) == 2 || ($course['courseClass'] ?? '') == 'online';
            $isF2f = ($course['courseTypeID'] ?? 0) == 1 || ($course['courseClass'] ?? '') == 'f2f';
            
            return (in_array('online', $courseTypes) && $isOnline) || 
                   (in_array('f2f', $courseTypes) && $isF2f);
        });
    }
    
    // Apply sorting
    if (!empty($sortBy)) {
        usort($filteredCourses, function($a, $b) use ($sortBy) {
            switch ($sortBy) {
                case 'name':
                    return strcasecmp($a['courseName'] ?? '', $b['courseName'] ?? '');
                case 'name-desc':
                    return strcasecmp($b['courseName'] ?? '', $a['courseName'] ?? '');
                case 'duration':
                    return (int)($a['courseDuration'] ?? 0) - (int)($b['courseDuration'] ?? 0);
                case 'duration-desc':
                    return (int)($b['courseDuration'] ?? 0) - (int)($a['courseDuration'] ?? 0);
                default:
                    return 0;
            }
        });
    }
    
    $filteredCourses = array_values($filteredCourses); // Re-index array
}

// Add debug info to context for temporary visibility
$debugInfo = [
    'allCoursesCount' => is_array($allCoursesData) ? count($allCoursesData) : 'not array',
    'allCoursesType' => gettype($allCoursesData),
    'timestamp' => date('Y-m-d H:i:s')
];

$context = Timber::context();

// Get the csds courses 
if (!empty($filteredCourses)) {
    error_log('DEBUG: First course structure: ' . print_r($filteredCourses[0], true));
    error_log('DEBUG: Available keys in first course: ' . implode(', ', array_keys($filteredCourses[0])));
}

$context['courses'] = $courseData;
$context['allCourses'] = $filteredCourses;
$context['courseUrl'] = $courseUrl;
$context['searchTerm'] = $searchTerm;
$context['courseTypes'] = $courseTypes;
$context['sortBy'] = $sortBy;
$context['hasFilters'] = !empty($searchTerm) || !empty($courseTypes) || !empty($sortBy);
$context['debugInfo'] = $debugInfo;

Timber::render('templates/page-courses.twig', $context);
