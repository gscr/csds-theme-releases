<?php

acf_add_local_field_group([
    'key' => 'group_resource_loop',
    'title' => 'Resource Loop Settings',
    'fields' => [
        [
            'key' => 'field_resource_posts_per_page',
            'label' => 'Resources per page',
            'name' => 'posts_per_page',
            'type' => 'number',
            'instructions' => 'Enter the number of resources to display',
            'required' => 1,
            'default_value' => 6,
            'min' => 3,
            'max' => 12,
        ],
        [
            'key' => 'field_resource_posts_offset',
            'label' => 'Resources offset',
            'name' => 'posts_offset',
            'type' => 'number',
            'instructions' => 'Skip this many resources from the beginning (0 = start from first resource)',
            'required' => 0,
            'default_value' => 0,
            'min' => 0,
            'max' => 100,
        ],
        [
            'key' => 'field_resource_show_more_button',
            'label' => 'Show "More resources" button',
            'name' => 'show_more_button',
            'type' => 'true_false',
            'instructions' => 'Enable to display a "More resources" button at the bottom (only when pagination is disabled)',
            'default_value' => 1,
            'ui' => 1,
            'conditional_logic' => [
                [
                    [
                        'field' => 'field_resource_enable_pagination',
                        'operator' => '!=',
                        'value' => '1',
                    ]
                ]
            ],
        ],
        [
            'key' => 'field_resource_button_text',
            'label' => 'Button text',
            'name' => 'button_text',
            'type' => 'link',
            'instructions' => 'Enter the text and link for the "More resources" button',
            'required' => 0,
            'conditional_logic' => [
                [
                    [
                        'field' => 'field_resource_show_more_button',
                        'operator' => '==',
                        'value' => '1',
                    ],
                    [
                        'field' => 'field_resource_enable_pagination',
                        'operator' => '!=',
                        'value' => '1',
                    ]
                ]
            ],
            'return_format' => 'array',
        ],
        [
            'key' => 'field_resource_enable_pagination',
            'label' => 'Enable pagination',
            'name' => 'enable_pagination',
            'type' => 'true_false',
            'instructions' => 'Enable pagination for resources (disables "More resources" button)',
            'default_value' => 0,
            'ui' => 1,
        ],
        [
            'key' => 'field_resource_enable_filter',
            'label' => 'Enable resource type filter',
            'name' => 'enable_filter',
            'type' => 'true_false',
            'instructions' => 'Show a horizontal filter bar to filter resources by type',
            'default_value' => 0,
            'ui' => 1,
        ],
    ],
    'location' => [
        [
            [
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/resource-loop',
            ],
        ],
    ],
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
]);
