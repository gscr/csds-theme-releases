<?php
namespace App;

use Timber\Timber;

$context = Timber::context();
$post = $context['post'];
$templates = array('templates/single-' . $post->post_type . '.twig', 'templates/single.twig');

$context['enable_toc'] = get_field('enable_table_of_contents');

if (post_password_required($post->ID)) {
	$templates = 'templates/single-password.twig';
} 

Timber::render($templates, $context);
