<?php
/**
 * Template Name: Courses
 * Description: A Page Template for courses.
 */

namespace App;

use Timber\Timber;

// Define API endpoints
$baseUrl = 'https://central.csds.qld.edu.au';
$requestUrl = $baseUrl . '/api/v2/courses/fetch-landing';
$courseUrl = $baseUrl . '/central/courses';

// Fetch course data with error handling
try {
    $response = wp_remote_get($requestUrl, [
        'sslverify' => false,
        'timeout' => 15,
        'headers' => [
            'Accept' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        throw new \Exception('Failed to fetch courses: ' . $response->get_error_message());
    }

    $responseCode = wp_remote_retrieve_response_code($response);
    if ($responseCode !== 200) {
        throw new \Exception('Invalid API response code: ' . $responseCode);
    }

    $fetchedJSON = wp_remote_retrieve_body($response);
    $courseData = json_decode($fetchedJSON, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new \Exception('Invalid JSON response: ' . json_last_error_msg());
    }
} catch (\Exception $e) {
    // Log error and set empty course data
    error_log($e->getMessage());
    $courseData = null;
}

$context = Timber::context();

// Get the csds courses 
$context['courses'] = $courseData;
$context['courseUrl'] = $courseUrl;

Timber::render('templates/page-courses.twig', $context);