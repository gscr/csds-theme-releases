<?php
acf_add_local_field_group(
    array(
        'key' => 'group_styled_links_item_block',
        'title' => 'Styled links item container.',
        'fields' => array(
            array(
                'key' => 'st_links_item_link',
                'label' => 'Link',
                'name' => 'link',
                'type' => 'link',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/styled-links-item-block',
                ),
            ),
        ),
    )
);