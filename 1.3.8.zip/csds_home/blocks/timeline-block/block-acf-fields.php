<?php

acf_add_local_field_group(
    array(
        'key' => 'group_timeline_block',
        'title' => 'Timeline Block Fields',
        'fields' => array(
            array(
            'key' => 'st_timeline_heading_field',
            'label' => 'Heading',
            'name' => 'timeline_heading',
            'type' => 'text',
            'default_value' => '',
            'placeholder' => 'Enter heading here',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/timeline-block',
                ),
            ),
        ),
    )
);

