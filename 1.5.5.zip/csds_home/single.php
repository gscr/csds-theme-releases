<?php
namespace App;

use Timber\Timber;

$context = Timber::context();
$post = $context['post'];
$templates = array('templates/single-' . $post->post_type . '.twig', 'templates/single.twig');

$context['enable_toc'] = get_field('enable_table_of_contents');


// Add project-specific ACF fields to context
if ($post->post_type === 'project') {
	$context['enable_project_sidebar'] = get_field('enable_project_sidebar');
	$context['project_sidebar_position'] = get_field('project_sidebar_position');
	
	// Add project taxonomies to context
	$project_taxonomies = [];
	$taxonomies = get_object_taxonomies($post->post_type, 'names');
	foreach ($taxonomies as $taxonomy) {
		$terms = get_the_terms($post->ID, $taxonomy);
		if ($terms && !is_wp_error($terms)) {
			$project_taxonomies = array_merge($project_taxonomies, $terms);
		}
	}
	$context['project_taxonomies'] = $project_taxonomies;
}

if (post_password_required($post->ID)) {
	$templates = 'templates/single-password.twig';
} 

Timber::render($templates, $context);
