<?php

acf_add_local_field_group(array(
    'key' => 'group_tab_item_block',
    'title' => 'Tab Item Block Fields',
    'fields' => array(
        array(
            'key' => 'st_tab_item_heading',
            'label' => 'Tab Heading',
            'name' => 'tab_item_heading',
            'default_value' => 'Tab Item Heading',
            'type' => 'text',
            'instructions' => 'Enter the heading for the tab item.',
            'required' => true,
        )
    ),
    'location' => array(
        array(
            array(
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/tab-item-block',
            ),
        ),
    ),
));
