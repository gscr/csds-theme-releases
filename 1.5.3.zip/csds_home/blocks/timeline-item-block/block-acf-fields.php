<?php
acf_add_local_field_group(
    array(
        'key' => 'group_timeline_item_block',
        'title' => 'Timeline Item Block Fields',
        'fields' => array(
            array(
            'key' => 'st_timeline_item_year_field',
            'label' => 'Year',
            'name' => 'timeline_item_year',
            'type' => 'text',
            'default_value' => '',
            'placeholder' => 'Enter year or date here',
            ),
            array(
                'key' => 'st_timeline_item_image_field',
                'label' => 'Image',
                'name' => 'timeline_item_image',
                'type' => 'image',
                'return_format' => 'url',
                'preview_size' => 'medium',
                'library' => 'all',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/timeline-item-block',
                ),
            ),
        ),
    )
);
