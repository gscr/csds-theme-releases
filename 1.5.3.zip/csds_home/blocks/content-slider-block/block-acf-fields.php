<?php
acf_add_local_field_group(
    array(
        'key' => 'group_content_slider_block',
        'title' => 'Content Slider Block Fields',
        'fields' => array(
            array(
                'key' => 'st_slider_title',
                'label' => 'Slider Title',
                'name' => 'slider_title',
                'type' => 'text',
                'wrapper' => array(
                    'class' => 'st-slider-title',
                ),
            ),
            array(
                'key' => 'st_items_to_show_desktop',
                'label' => 'Number of items to show (Desktop)',
                'name' => 'items_to_show_desktop',
                'type' => 'radio',
                'choices' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                ),
                'wrapper' => array(
                    'class' => 'st-column-picker',
                ),
            ),
            array(
                'key' => 'st_items_to_show_mobile',
                'label' => 'Number of items to show (Mobile)',
                'name' => 'items_to_show_mobile',
                'type' => 'radio',
                'choices' => array(
                    '1' => '1',
                    '2' => '2',
                ),
                'wrapper' => array(
                    'class' => 'st-column-picker',
                ),
            ),
            array(
                'key' => 'st_item_gap',
                'label' => 'Item Gap',
                'name' => 'item_gap',
                'type' => 'radio',
                'choices' => array(
                    '8' => 'Small',
                    '16' => 'Medium',
                    '24' => 'Large',
                ),
                'wrapper' => array(
                    'class' => 'st-gap-picker',
                ),
            ),
            array(
                'key' => 'st_slider_padding',
                'label' => 'Container padding',
                'name' => 'slider_padding',
                'type' => 'radio',
                'choices' => array(
                    '0' => 'None',
                    '4' => 'Small',
                    '8' => 'Medium',
                    '16' => 'Large',
                    '24' => 'XL',
                ),
                'wrapper' => array(
                    'class' => 'st-padding-picker',
                ),
            ),
            array(
                'key' => 'st_slider_background_color_radio',
                'label' => 'Background Color',
                'name' => 'slider_background_color_radio',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_slider_text_color_radio',
                'label' => 'Title Color',
                'name' => 'slider_text_color_radio',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_slider_include_background_video',
                'label' => 'Moving gradient',
                'name' => 'slider_background_video',
                'type' => 'true_false',
                'instructions' => 'Show the csds moving gradient',
                'default_value' => 0,
                'ui' => 1,
                'ui_on_text' => 'Yes',
                'ui_off_text' => 'No',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/content-slider-block',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=slider_background_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=slider_text_color_radio', 'wd_acf_dynamic_colors_load');