<?php
require_once __DIR__ . '/vendor/autoload.php';
Timber\Timber::init();

/**
 * Theme setup.
 */
function st_setup()
{
	add_theme_support('title-tag');

	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		)
	);

	add_theme_support('custom-logo');
	add_theme_support('post-thumbnails');

	add_theme_support('align-wide');
	add_theme_support('wp-block-styles');

	add_theme_support('editor-styles');
	add_editor_style('css/editor-style.css');
}

add_action('after_setup_theme', 'st_setup');

/**
 * Enqueue theme assets.
 */
function st_enqueue_scripts()
{
	$theme = wp_get_theme();

	wp_enqueue_style('st', st_asset('css/app.css'), array(), $theme->get('Version'));
	wp_enqueue_script('st', st_asset('js/app.js'), array(), $theme->get('Version'));
	wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap', false);
}

add_action('wp_enqueue_scripts', 'st_enqueue_scripts');

/**
 * Debug global styles generation (temporary - remove when confirmed working)
 */
// function st_debug_global_styles() {
// 	echo '<!-- DEBUG INFO: ';
// 	echo 'Environment type: ' . wp_get_environment_type() . ' | ';
// 	echo 'Global styles enqueued: ' . (isset($GLOBALS['wp_styles']->registered['global-styles']) ? 'true' : 'false');
// 	echo ' -->';
// }
// add_action('wp_head', 'st_debug_global_styles');

/**
 * Enqueue script for Gutenberg editor.
 */
function st_enqueue_block_editor_assets()
{
	$theme = wp_get_theme();
	wp_enqueue_script('st-editor', st_asset('js/app.js'), array(), $theme->get('Version'), true);
}
add_action('enqueue_block_editor_assets', 'st_enqueue_block_editor_assets');

/**
 * Enqueue admin styles.
 */
function st_admin_style()
{
	wp_enqueue_style('st', st_asset('css/admin-style.css'));
}
add_action('admin_enqueue_scripts', 'st_admin_style');

/**
 * Preconnect for google fonts.
 */
function st_preconnect_google_fonts()
{
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
	echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}
add_action('wp_head', 'st_preconnect_google_fonts');

/**
 * Enqueue Google Analytics (gtag.js).
 */
function st_enqueue_google_analytics()
{
	// Only load on frontend, not in admin
	if (is_admin()) {
		return;
	}

	// Google Analytics tracking ID
	$ga_tracking_id = 'G-B7DMH4FZVX';

	// Enqueue the gtag.js script
	wp_enqueue_script(
		'google-gtag',
		'https://www.googletagmanager.com/gtag/js?id=' . $ga_tracking_id,
		array(),
		null,
		false // Load in head for proper tracking
	);

	// Add async attribute to the script
	add_filter('script_loader_tag', function($tag, $handle) {
		if ('google-gtag' === $handle) {
			return str_replace(' src', ' async src', $tag);
		}
		return $tag;
	}, 10, 2);

	// Add the gtag configuration inline script
	wp_add_inline_script('google-gtag', "
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', '" . $ga_tracking_id . "');
	");
}

add_action('wp_enqueue_scripts', 'st_enqueue_google_analytics');

/**
 * Disable global styles in head (legacy function - kept for compatibility)
 */
function remove_global_styles()
{
	wp_dequeue_style('global-styles');
}

add_action('wp_enqueue_scripts', 'remove_global_styles');

/**
 * Remove global styles more aggressively - at multiple points
 */
function st_remove_global_styles_aggressive() {
	global $wp_styles;
	
	// Remove from registered styles
	if (isset($wp_styles->registered['global-styles'])) {
		unset($wp_styles->registered['global-styles']);
	}
	
	// Remove from queue
	if (($key = array_search('global-styles', $wp_styles->queue ?? [])) !== false) {
		unset($wp_styles->queue[$key]);
	}
	
	// Remove any inline global styles
	if (isset($wp_styles->registered['global-styles'])) {
		$wp_styles->registered['global-styles']->extra = [];
	}
}

// Remove at multiple hook points to catch re-additions
add_action('wp_enqueue_scripts', 'st_remove_global_styles_aggressive', 999);
add_action('wp_head', 'st_remove_global_styles_aggressive', 1);
add_action('wp_print_styles', 'st_remove_global_styles_aggressive');

/**
 * Get asset path.
 */
function st_asset($path)
{
	if (wp_get_environment_type() === 'production') {
		return get_stylesheet_directory_uri() . '/' . $path;
	}

	return add_query_arg('time', time(), get_stylesheet_directory_uri() . '/' . $path);
}
/**
 * Register widget areas for the footer.
 */
function st_register_footer_widget_areas()
{
	register_sidebar(
		array(
			'name' => __('Page sidebar', 'st'),
			'id' => 'page-sidebar',
			'description' => __('Widget area for the page sidebar.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 1', 'st'),
			'id' => 'footer-widget-1',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 2', 'st'),
			'id' => 'footer-widget-2',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Footer Widget Area 3', 'st'),
			'id' => 'footer-widget-3',
			'description' => __('Widget area for the footer.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name' => __('Resource Sidebar', 'st'),
			'id' => 'resource-sidebar',
			'description' => __('Widget area for the resource archive and single pages.', 'st'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h4 class="widget-title">',
			'after_title' => '</h4>',
		)
	);
}
add_action('widgets_init', 'st_register_footer_widget_areas');

/** 
 * Timber context
 * Add global context variables for Timber (items that are available in all templates)
 */
add_filter('timber/context', function ($context) {
	// Get all registered menus
	$menus = get_registered_nav_menus();

	// Loop through each registered menu and add it to the context
	foreach ($menus as $location => $description) {
		$context['menu_' . $location] = Timber::get_menu($location);
	}

	// Define 'is_dev' flag based on URL patterns
	$context['is_dev'] = strpos(home_url(), 'localhost') !== false || strpos(home_url(), '.local') !== false || strpos(home_url(), '.wplocal') !== false;

	// We're now using the get_param Twig function directly in templates
	// instead of setting course_name in the context
	
	$context['logo'] = wp_get_attachment_image(get_theme_mod('custom_logo'), 'thumbnail');
	$context['header_text'] = get_theme_mod('theme_header_text', '');
	$context['header_link'] = get_theme_mod('theme_header_link', '');
	$context['footer_copy'] = get_theme_mod('theme_footer_copyright_text', '');
	$context['footer_text_area'] = get_theme_mod('theme_footer_text_area', '');
	$context['page_sidebar_widget'] = Timber::get_widgets('page-sidebar');
	$context['resource_sidebar_widget'] = Timber::get_widgets('resource-sidebar');
	$context['footer_widget_1'] = Timber::get_widgets('footer-widget-1');
	$context['footer_widget_2'] = Timber::get_widgets('footer-widget-2');
	$context['footer_widget_3'] = Timber::get_widgets('footer-widget-3');
	
	// Add courses page URL for search toggle functionality
	$courses_page_id = get_theme_mod('courses_filter_action_page', 0);
	$context['courses_page_url'] = $courses_page_id ? get_permalink($courses_page_id) : '/courses/';
	$context['search_query'] = get_search_query();

	return $context;

});

/**
 * Add a custom function to safely get URL parameters in Twig templates
 */
add_filter('timber/twig', function($twig) {
    $twig->addFunction(new \Twig\TwigFunction('get_param', function($param_name, $default = '') {
        if (isset($_GET[$param_name])) {
            // Get the raw value first
            $value = $_GET[$param_name];
            
            // URL decode it (handles %20, %27, etc.)
            $value = urldecode($value);
            
            // Basic sanitization but preserve special characters
            $value = wp_kses($value, array());
            
            // Remove slashes that might have been added
            $value = stripslashes($value);
            
            return $value;
        }
        return $default;
    }));
    
    return $twig;
});

/*
 * Includes
 */
require_once get_template_directory() . '/inc/customiser.php'; // Customiser settings
require_once get_template_directory() . '/inc/admin.php'; // Custom settings for WP admin
require_once get_template_directory() . '/inc/acf-fields.php'; // Custom settings for WP admin

/*
 * Add all block files in the blocks directory
 */
function register_acf_blocks()
{
	foreach ($blocks = new DirectoryIterator(__DIR__ . '/blocks') as $item) {
		// Check if block.json file exists in each subfolder.
		if (
			$item->isDir() && !$item->isDot()
			&& file_exists($item->getPathname() . '/block.json')
		) {
			// Register the block given the directory name within the blocks
			// directory.
			register_block_type_from_metadata($item->getPathname());
		}
	}
}

add_action('init', 'register_acf_blocks');

/*
 * Load acf block fields
 */
foreach ($blocks = new DirectoryIterator(__DIR__ . '/blocks') as $item) {
	if (
		$item->isDir() && !$item->isDot()
		&& file_exists($item->getPathname() . '/block-acf-fields.php')
	) {
		require_once $item->getPathname() . '/block-acf-fields.php';
	}
}

/**
 * Render callback to prepare and display a registered block using Timber.
 *
 */
function st_acf_block_render_callback($attributes, $content = '', $is_preview = false, $post_id = 0, $wp_block = null)
{
	// Create the slug of the block using the name property in the block.json.
	$slug = str_replace('acf/', '', $attributes['name']);

	$context = Timber::context();

	// Store block attributes.
	$context['attributes'] = $attributes;
	$context['block_content'] = $content;

	// Store field values. These are the fields from your ACF field group for the block.
	$context['fields'] = get_fields();

	// Store whether the block is being rendered in the editor or on the frontend.
	$context['is_preview'] = $is_preview;

	// Render the block.
	Timber::render(
		'blocks/' . $slug . '/' . $slug . '.twig',
		$context
	);
}


/**
 * Generates a group hash by concatenating a prefix with the MD5 hash of the identifier and site URL.
 * __FILE__ is used to ensure that the hash is unique to the current file.
 *
 */
function generate_hash($prefix, $identifier, $file = __FILE__)
{
	return $prefix . md5($identifier . $file . site_url());
}

// Add IDs to headings

function add_heading_ids($content)
{
	$matches = [];
	// Use a more flexible regex to match headings
	preg_match_all('/<h([2-3])\b([^>]*)>(.*?)<\/h[2-3]>/', $content, $matches, PREG_SET_ORDER);

	$counter = 1;

	foreach ($matches as $match) {
		$level = $match[1];
		$attributes = $match[2];
		$title = $match[3];
		// Generate an ordered ID
		$id = 'h' . str_pad($counter, 2, '0', STR_PAD_LEFT);
		$counter++;

		// Replace the heading with the new ID added, keeping existing attributes
		$new_heading = '<h' . $level . ' id="' . $id . '"' . $attributes . '>' . $title . '</h' . $level . '>';
		$content = str_replace($match[0], $new_heading, $content);

		// Log the new heading
		error_log('New heading: ' . $new_heading);
	}

	// Log the final content
	error_log('Final content: ' . $content);

	return $content;
}

// Generate the Table of Contents
function generate_toc($content)
{
	$toc = '';
	$matches = [];
	// Adjust regex to match headings with the generated IDs
	preg_match_all('/<h([2-3])\b[^>]*id="(h\d{2})"[^>]*>(.*?)<\/h[2-3]>/', $content, $matches, PREG_SET_ORDER);

	if ($matches) {
		$toc .= '<nav id="gen-toc"><p class="my-0 font-bold">On this page</p><ul>';
		foreach ($matches as $match) {
			$level = $match[1] - 1;
			$id = $match[2];
			$title = $match[3];
			$toc .= '<li class="lvl' . $level . '"><a href="#' . $id . '">' . $title . '</a></li>';
		}
		$toc .= '</ul></nav>';
	}

	return $toc;
}


// Register the filter and function in Timber Twig
add_filter('timber/twig/filters', function ($filters) {
	$filters['add_heading_ids'] = [
		'callable' => 'add_heading_ids'
	];
	return $filters;
});

add_filter('timber/twig/functions', function ($functions) {
	$functions['generate_toc'] = [
		'callable' => 'generate_toc',
	];
	return $functions;
});

// post query function
function get_custom_post_loop($args) {
    $default_args = array(
        'post_type' => 'post',
        'posts_per_page' => 6,
        'orderby' => 'date',
        'order' => 'DESC',
        'post_status' => 'publish'
    );

    $query_args = wp_parse_args($args, $default_args);
    return Timber::get_posts($query_args);
}

// Add custom function to Timber Twig
add_filter('timber/twig/functions', function ($functions) {
    $functions['post_query'] = [
        'callable' => 'get_custom_post_loop'
    ];
    return $functions;
});


// Change oEmbed container to be responsive
function wpcode_snippet_oembed_defaults($sizes)
{
	return array(
		'width' => '100%',
		'height' => 0, // Set to 0 to maintain aspect ratio
	);
}

function wpstarter_embed_html($html)
{
	return '<div class="embed-responsive" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">' .
		'<div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">' .
		// Add class for any iframe to make it responsive
		str_replace('<iframe', '<iframe style="width:100%;height:100%;"', $html) .
		'</div>' .
		'</div>';
}

add_filter('embed_oembed_html', 'wpstarter_embed_html', 10, 3);
add_filter('video_embed_html', 'wpstarter_embed_html');

// add cpt to category archives
function include_custom_post_types_in_archives($query)
{
	if (is_category() && $query->is_main_query() && !is_admin()) {
		// Add your custom post types to the query
		$custom_post_types = get_post_types(['public' => true, '_builtin' => false]); // Get all public, non-built-in post types
		$post_types = array_merge(['post'], $custom_post_types);
		$query->set('post_type', $post_types);
	}
}
add_action('pre_get_posts', 'include_custom_post_types_in_archives');

/**
 * Generate a consistent snippet for search results.
 * - Prefer manual excerpt
 * - Otherwise, take first paragraph of content (strip blocks/shortcodes)
 * - Fallback to first N chars of stripped content
 */
function st_get_search_snippet($post, $max_len = 180)
{
    $post_id = is_object($post) && isset($post->ID) ? $post->ID : (int)$post;
    if (!$post_id) return '';

    // 1) Prefer manual excerpt
    $excerpt = get_post_field('post_excerpt', $post_id);
    if (!empty($excerpt)) {
        $text = wp_strip_all_tags($excerpt, true);
    } else {
        // 2) Use first paragraph from content
        $content = get_post_field('post_content', $post_id);
        if (!$content) return '';

        // Remove Gutenberg block comments
        $content = preg_replace('/<!--\s*\/?wp:[^>]*-->/', '', $content);
        // Remove shortcodes
        $content = strip_shortcodes($content);

        // Try to capture first paragraph
        if (preg_match('/<p[^>]*>(.*?)<\/p>/is', $content, $m) && !empty($m[1])) {
            $text = wp_strip_all_tags($m[1], true);
        } else {
            // Fallback to stripped content
            $text = wp_strip_all_tags($content, true);
        }
    }

    // Normalize whitespace
    $text = trim(preg_replace('/\s+/', ' ', $text));

    // Truncate
    if ($max_len > 0 && strlen($text) > $max_len) {
        $text = mb_substr($text, 0, $max_len);
        // Avoid cutting mid-word
        $text = preg_replace('/\s+\S*$/u', '', $text);
        $text .= '…';
    }

    return $text;
}

// Expose get_search_snippet to Twig
add_filter('timber/twig', function($twig) {
    $twig->addFunction(new \Twig\TwigFunction('get_search_snippet', 'st_get_search_snippet'));
    return $twig;
});

// Include selected post types in site search based on customizer settings
function include_selected_post_types_in_search($query)
{
    if ($query->is_search() && $query->is_main_query() && !is_admin()) {
        // Get selected searchable post types from customizer
        $searchable_post_types = get_searchable_post_types();
        $query->set('post_type', $searchable_post_types);
    }
}
add_action('pre_get_posts', 'include_selected_post_types_in_search');


/**
 * Add svg for duotone filter
 */

function add_svg_below_footer() {
    ?>
    <div style="display: none;">
        <?php echo file_get_contents(get_template_directory() . '/resources/img/svg/teal-duotone.svg'); ?>
    </div>
    <?php
}
add_action('wp_footer', 'add_svg_below_footer');


/*
 * Add colours to categories
 */

 function get_category_colour_class($category_slug) {
    $category_colours = [
        'primary' => 'white',
        'secondary' => 'black',
        'tertiary' => 'black',
        'tertiary-2' => 'white',
        'tertiary-3' => 'black',
        'tertiary-4' => 'white',
    ];

    $background_colours = array_keys($category_colours);

    // Hash the category slug to get a consistent index
    $index = crc32($category_slug) % count($background_colours);

    $background_class = $background_colours[$index];
    $text_class = $category_colours[$background_class];

    return [
        'background' => $background_class,
        'text' => $text_class,
    ];
}

add_filter('timber/twig', function($twig) {
    $twig->addFunction(new \Twig\TwigFunction('get_category_colour_class', 'get_category_colour_class'));
    return $twig;
});


add_filter('quform_post_process', function (array $result, Quform_Form $form) {
    try {
        // Get all the responses for this form submission
        $all_responses = $form->getValues();

        // Safely check for database enabled setting
        $config = $form->config();
        $databaseEnabled = isset($config['databaseEnabled']) ? $config['databaseEnabled'] : false;

        // Check for loggable form here
        if ($databaseEnabled === true) {
            // DB connection variables
            $servername = "microsites.crccn7gaftmv.ap-southeast-2.rds.amazonaws.com";
            $username = "quForm_user";
            $password = "B7nYxTDgwD5mJEEu";
            $dbname = "csds_dbo";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname, "4664");

            if (mysqli_connect_errno($conn)) {
                $err = mysqli_connect_error();
                error_log('QuForm Database connection failed: ' . $err);
                return $result; // Return instead of exit to allow form processing to continue
            }

            // Prepare statement once outside the loop for better performance
            $stmt = $conn->prepare("INSERT INTO `csds_dbo`.`tbl_quFormResponseData` (`formId`, `entryId`, `question`, `answer`) VALUES (?, ?, ?, ?)");
            
            if (!$stmt) {
                error_log('QuForm Failed to prepare statement: ' . $conn->error);
                $conn->close();
                return $result;
            }

            // Get form metadata once
            $formId = $form->getUniqueId();
            $entryId = $form->getEntryId();

            // Iterate and every answer to the question becomes a row in the DB
            foreach ($all_responses as $key => $value) {
                if (!empty($value)) {
                    // If the response is a multi-select value then break it down into comma separated values
                    if (is_array($value)) {
                        $value = implode(',', $value);
                    }

                    // Get element config safely
                    $element = $form->getElement($key);
                    if (!$element) {
                        continue; // Skip if element doesn't exist
                    }
                    
                    $keyConfig = $element->config();
                    
                    // Safely get the label with proper fallbacks
                    $keyLabel = $key; // Default fallback
                    if (!empty($keyConfig['label'])) {
                        $keyLabel = $keyConfig['label'];
                    } elseif (!empty($keyConfig['adminLabel'])) {
                        $keyLabel = $keyConfig['adminLabel'];
                    }

                    $stmt->bind_param('ssss', $formId, $entryId, $keyLabel, $value);

                    if (!$stmt->execute()) {
                        error_log('QuForm Failed to insert data: ' . $stmt->error);
                        // Continue processing other fields instead of exiting
                    }
                }
            }

            // Clean up resources
            $stmt->close();
            $conn->close();
        } else {
            error_log('QuForm Database logging not enabled for this form');
        }

    } catch (Exception $e) {
        error_log('QuForm post_process error: ' . $e->getMessage());
    }

    return $result;
}, 10, 2);