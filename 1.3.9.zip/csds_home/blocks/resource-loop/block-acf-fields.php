<?php

acf_add_local_field_group([
    'key' => 'group_resource_loop',
    'title' => 'Resource Loop Settings',
    'fields' => [
        [
            'key' => 'field_resource_posts_per_page',
            'label' => 'Resources Per Page',
            'name' => 'posts_per_page',
            'type' => 'number',
            'instructions' => 'Enter the number of resources to display',
            'required' => 1,
            'default_value' => 6,
            'min' => 3,
            'max' => 12,
        ],
        [
            'key' => 'field_resource_posts_offset',
            'label' => 'Resources Offset',
            'name' => 'posts_offset',
            'type' => 'number',
            'instructions' => 'Skip this many resources from the beginning (0 = start from first resource)',
            'required' => 0,
            'default_value' => 0,
            'min' => 0,
            'max' => 100,
        ],
        [
            'key' => 'field_resource_show_more_button',
            'label' => 'Show "More Resources" Button',
            'name' => 'show_more_button',
            'type' => 'true_false',
            'instructions' => 'Enable to display a "More Resources" button at the bottom',
            'default_value' => 1,
            'ui' => 1,
        ],
        [
            'key' => 'field_resource_button_text',
            'label' => 'Button Text',
            'name' => 'button_text',
            'type' => 'link',
            'instructions' => 'Enter the text and link for the "More Resources" button',
            'required' => 0,
            'conditional_logic' => [
                [
                    [
                        'field' => 'field_resource_show_more_button',
                        'operator' => '==',
                        'value' => '1',
                    ]
                ]
            ],
            'return_format' => 'array',
        ],
    ],
    'location' => [
        [
            [
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/resource-loop',
            ],
        ],
    ],
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
]);
