<?php
acf_add_local_field_group(
    array(
        'key' => 'group_styled_links_block',
        'title' => 'Styled links block container.',
        'fields' => array(
            array(
                'key' => 'st_links_fill',
                'label' => 'Style',
                'name' => 'links_fill',
                'type' => 'true_false',
                'ui' => 1,
                'default_value' => 0,
                'ui_on_text' => 'Filled',
                'ui_off_text' => 'Not Filled',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/styled-links-block',
                ),
            ),
        ),
    )
);