<?php
use OzdemirBurak\Iris\Color\Hex;

// Load data from theme.json
$theme_json_path = get_template_directory() . '/theme.json';
$theme_data = json_decode(file_get_contents($theme_json_path), true);

// Define the theme colours
// Naming convention is from theme.json
// These need to be manually set for custom ACF radio fields in css/admin-style.css
$theme_colours = [
    'light',
    'dark',
    'primary',
    'secondary',
    'tertiary',
    'tertiary-2',
    'tertiary-3',
    'tertiary-4'
];

/**
 * Define the customiser options
 */
add_action('customize_register', function ($wp_customize) use ($theme_data, $theme_colours) {
    // New section for theme colours
    $wp_customize->add_section('st_theme_colours', [
        'title' => __('Theme Colours', 'st'),
        'priority' => 32,
    ]);

    // Add settings and controls for each theme colour
    foreach ($theme_colours as $i => $colour) {
        // Generate the key and value for the current colour
        $colour_key = 'st_' . $colour;
        $colour_value = $theme_data['settings']['color']['palette'][$i]['color'];

        // Add a setting for the current colour
        $wp_customize->add_setting($colour_key, [
            'default' => $colour_value,
            'transport' => 'refresh',
        ]);

        // Add a control for the current colour
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $colour_key, [
            'label' => __(ucwords(str_replace('_', ' ', $colour)), 'st'),
            'section' => 'st_theme_colours',
            'settings' => $colour_key,
        ]));
    }

    // New section for the header settings
    $wp_customize->add_section('st_header_settings', [
        'title' => __('Header Settings', 'st'),
        'priority' => 30,
    ]);

    // Setting for the header text
    $wp_customize->add_setting('theme_header_text', [
        'default' => 'health.qld.gov.au',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // Control for the header text
    $wp_customize->add_control('theme_header_text', [
        'label' => __('Header Text', 'st'),
        'section' => 'st_header_settings',
        'type' => 'text',
    ]);

    // Setting for the header link
    $wp_customize->add_setting('theme_header_link', [
        'default' => 'https://health.qld.gov.au',
        'transport' => 'refresh',
    ]);

    // Control for the header link
    $wp_customize->add_control('theme_header_link', [
        'label' => __('Header Link', 'st'),
        'section' => 'st_header_settings',
        'type' => 'url',
    ]);

    // New section for the footer settings
    $wp_customize->add_section('st_footer_settings', [
        'title' => __('Footer Settings', 'st'),
        'priority' => 31,
    ]);

    // Setting for the footer copyright text
    $wp_customize->add_setting('theme_footer_copyright_text', [
        'default' => 'The State of Queensland (Queensland Health)',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // Control for the footer copyright text
    $wp_customize->add_control('theme_footer_copyright_text', [
        'label' => __('Footer Copyright Text', 'st'),
        'section' => 'st_footer_settings',
        'type' => 'text',
    ]);

    // Setting for the footer text area
    $wp_customize->add_setting('theme_footer_text_area', [
        'default' => 'We acknowledge the Traditional Owners and custodians of the lands from across Queensland. We pay our respects to the Elders past and present for they are holders of the memories, traditions, the culture and aspirations of Aboriginal and Torres Strait Islander peoples across Queensland. ',
        'transport' => 'refresh',
        'sanitize_callback' => 'sanitize_textarea_field',
    ]);
    // Control for the footer text area
    $wp_customize->add_control('theme_footer_text_area', [
        'label' => __('Footer Acknowledgement', 'st'),
        'section' => 'st_footer_settings',
        'type' => 'textarea',
    ]);
});


/**
 * Retrieves the current colour palette from the customiser settings.
 */
function get_customiser_colour_palette()
{
    global $theme_colours, $theme_data;
    return array_map(function ($colour) use ($theme_data) {
        $colour_key = 'st_' . $colour;
        // Find the default colour from $theme_data based on the colour name
        $default_colour = '#000000'; // Fallback to black if not found in $theme_data
        foreach ($theme_data['settings']['color']['palette'] as $palette) {
            if ($palette['slug'] === $colour) {
                $default_colour = $palette['color'];
                break;
            }
        }
        $colour_value = get_theme_mod($colour_key, $default_colour);
        return [
            'name' => ucwords(str_replace('_', ' ', $colour)),
            'slug' => $colour,
            'color' => $colour_value,
        ];
    }, $theme_colours);
}

/**
 * Updates the block editor colour palette based on customiser settings.
 */
function update_block_editor_colours()
{
    $palette = get_customiser_colour_palette();
    add_theme_support('editor-color-palette', $palette);
}
add_action('after_setup_theme', 'update_block_editor_colours');

/**
 * Ensures the Gutenberg colour palette is updated after customiser settings are saved.
 */
function on_customiser_save_update_gutenberg_colours()
{
    update_block_editor_colours(); // Refresh the Gutenberg colour palette.
}
add_action('customize_save_after', 'on_customiser_save_update_gutenberg_colours');

/**
 * Filters the block editor settings to include the customiser theme colours.
 * Ensures that the editor settings are always using the latest palette.
 */
function filter_block_editor_settings($settings, $post)
{
    // Ensure get_customiser_colour_palette() is defined and returns the expected format.
    $custom_colours = get_customiser_colour_palette();
    if (is_array($custom_colours)) {
        // Block editor colour settings
        $settings['colors'] = $custom_colours;
        // Block editor colour picker theme section
        $settings['__experimentalFeatures']['color']['palette']['theme'] = $custom_colours;

        // Apply the custom colours to block editor 
        $custom_css = 'body{';
        $root_css = ':root{';
        foreach ($custom_colours as $colour) {
            $slug = str_replace(' ', '-', strtolower($colour['name'])); // Convert name to slug format
            $custom_css .= "--wp--preset--color--{$slug}: {$colour['color']};";
            $root_css .= "--wp--preset--color--{$slug}: {$colour['color']};";
        }
        $custom_css .= '}';
        $root_css .= '}';

        // Update the styles array with custom CSS
        $settings['styles'][3] = [
            'css' => $custom_css,
            '__unstableType' => 'presets',
            'isGlobalStyles' => 1,
        ];

        // Store the root CSS in a transient or option for later use
        set_transient('custom_root_css', $root_css, 12 * HOUR_IN_SECONDS);

        // Update the --wp--preset--color options in $settings['styles'][0]
        if (isset($settings['styles'][0]['css'])) {
            $styles_css = $settings['styles'][0]['css'];
            foreach ($custom_colours as $colour) {
                $slug = str_replace(' ', '-', strtolower($colour['name'])); // Convert name to slug format
                $styles_css = preg_replace(
                    "/--wp--preset--color--{$slug}:.*?;/",
                    "--wp--preset--color--{$slug}: {$colour['color']};\n",
                    $styles_css
                );
            }
            $settings['styles'][0]['css'] = $styles_css;
        }
    }
    return $settings;
}
// Try using 'block_editor_settings' if 'block_editor_settings_all' does not work as expected.
add_filter('block_editor_settings_all', 'filter_block_editor_settings', 10, 2);

/**
 * Enqueues custom admin styles in the admin area.
 */
function enqueue_custom_admin_styles()
{
    // Retrieve the custom root CSS from the transient or option
    $root_css = get_transient('custom_root_css');
    if ($root_css) {
        // Output the custom CSS in the admin area
        echo '<style>' . $root_css . '</style>';
    }
}
add_action('admin_head', 'enqueue_custom_admin_styles');

/**
 * Output theme colours as CSS variables in the header under :root {}
 * Tailwind uses these variables for colour classes e.g. text-primary, bg-secondary etc.
 * Function also uses a php library (Iris added via composer) to automatically generate light and dark shades of the colours. This should work most of the time but some colours may need manual adjustment/declarations
 */
function output_theme_colours()
{
    global $theme_colours, $theme_data;
    $output = "<style>\n:root {\n";

    // Loop through each theme colour
    foreach ($theme_colours as $i => $colour) {
        // Generate the key for the current colour
        $colour_key = 'st_' . $colour;
        // Get the RGB values from the customiser, default to the theme.json value if customiser is not set
        if (isset($theme_data['settings']['color']['palette'][$i]['color'])) {
            $colour_mod = get_theme_mod($colour_key, $theme_data['settings']['color']['palette'][$i]['color']);
        } else {
            // Provide a default color or handle the error as needed
            $colour_mod = get_theme_mod($colour_key, '#000000'); // Default to black if not set
        }
        $colour_value = new Hex($colour_mod ?: '#000000'); // Fallback to black if null
        $rgb_values = sscanf($colour_value->toRGB(), "rgb(%d,%d,%d)");

        // Append the CSS variable to the output
        $output .= "    --color-$colour: " . $rgb_values[0] . " " . $rgb_values[1] . " " . $rgb_values[2] . ";\n";

        // Use the Iris library to adjust brightness
        // Check if the colour is close to white
        $is_close_to_white = $rgb_values[0] > 200 && $rgb_values[1] > 200 && $rgb_values[2] > 200;

        // Reduce the lighten/darken precentage if the colour is close to white
        if ($is_close_to_white) {
            $light_colour_values = sscanf($colour_value->toRGB()->lighten(1), "rgb(%d,%d,%d)");
            $dark_colour_values = sscanf($colour_value->toRGB()->darken(1), "rgb(%d,%d,%d)");
        } else {
            $light_colour_values = sscanf($colour_value->toRGB()->lighten(8), "rgb(%d,%d,%d)");
            $dark_colour_values = sscanf($colour_value->toRGB()->darken(8), "rgb(%d,%d,%d)");
        }

        // Append the CSS variables for light and dark versions of the colour to the output
        $output .= "    --color-$colour-light: " . $light_colour_values[0] . " " . $light_colour_values[1] . " " . $light_colour_values[2] . ";\n";
        $output .= "    --color-$colour-dark: " . $dark_colour_values[0] . " " . $dark_colour_values[1] . " " . $dark_colour_values[2] . ";\n";
    }

    $output .= "  }</style>";

    echo $output;
}
add_action('wp_head', 'output_theme_colours');
add_action('admin_head', 'output_theme_colours'); // add the colour variables to the admin area as well for ACF fields


/**
 * Function to add colour swatches to acf radio fields
 */

function wd_acf_dynamic_colors_load($field)
{

    // get array of colors created using editor-color-palette
    $colors = get_theme_support('editor-color-palette');

    // if this array is empty, continue
    if (!empty($colors)) {

        // loop over each color and create option
        foreach ($colors[0] as $color) {
            $field['choices'][$color['slug']] = "";
        }
    }

    return $field;
}