<?php
acf_add_local_field_group(
    array(
        'key' => 'group_custom_image_block',
        'title' => 'Custom Image Block Fields',
        'fields' => array(
            array(
                'key' => 'st_custom_image_rounded',
                'label' => 'Rounded corners',
                'name' => 'custom_image_rounded',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_custom_image_duotone',
                'label' => 'DuoTone',
                'name' => 'custom_image_duotone',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_custom_image_cover',
                'label' => 'Fill container',
                'name' => 'custom_image_cover',
                'description' => 'This will make the image fill the container',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_custom_image',
                'label' => 'Image',
                'name' => 'custom_image',
                'type' => 'image',
                'return_format' => 'array',
                'preview_size' => 'medium',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/custom-image-block',
                ),
            ),
        ),
    )
);