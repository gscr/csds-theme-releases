<?php

acf_add_local_field_group(
    array(
        'key' => 'group_tab_block',
        'title' => 'Tab Block Fields',
        'fields' => array(
            array(
                'key' => 'st_tab_fill',
                'label' => 'Tab background',
                'name' => 'tab_fill',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                )
            ),
            array(
                'key' => 'st_tab_text_color',
                'label' => 'Text Colour',
                'name' => 'tab_text_color',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                )
            ),
            array(
                'key' => 'st_tab_indicator_color',
                'label' => 'Indicator Colour',
                'name' => 'tab_indicator_color_radio',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'primary',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_tab_hover_indicator_color',
                'label' => 'Hover Indicator Colour',
                'name' => 'tab_hover_indicator_color',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'secondary',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/tab-block',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=tab_fill', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=tab_text_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=tab_indicator_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=tab_hover_indicator_color', 'wd_acf_dynamic_colors_load');

