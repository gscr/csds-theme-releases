import Swiper from "swiper";
import { Pagination, Autoplay } from "swiper/modules";

// Initialize accordion functionality
function initAccordion() {
  document.querySelectorAll("[data-accordion-toggle]").forEach((toggle) => {
    toggle.removeEventListener("click", handleAccordionToggle);
    toggle.addEventListener("click", handleAccordionToggle);
  });
}

// Toggle accordion open/close
function handleAccordionToggle(event) {
  const toggle = event.currentTarget;
  const content = toggle.nextElementSibling;
  const chevron = toggle.querySelector(".chevron");

  if (content.classList.contains("max-h-0")) {
    content.classList.remove("max-h-0");
    content.classList.add("max-h-full");
    chevron.classList.add("rotate-180");
  } else {
    content.classList.remove("max-h-full");
    content.classList.add("max-h-0");
    chevron.classList.remove("rotate-180");
  }
}

// Initialise mobile menu toggle
function initMobileMenu() {
  const mainNavigation = document.querySelector("#primary-menu");
  const menuToggle = document.querySelector("#primary-menu-toggle");

  if (mainNavigation && menuToggle) {
    menuToggle.addEventListener("click", (e) => {
      e.preventDefault();
      mainNavigation.classList.toggle("hidden");
    });
  }
}

// Handle chevron click for submenus
function handleSubmenuToggle() {
  document.querySelectorAll("#primary-menu .chevron").forEach((chevron) => {
    chevron.removeEventListener("click", handleChevronClick);
    if (window.innerWidth <= 959) {
      chevron.addEventListener("click", handleChevronClick);
    }
  });
}

// Toggle submenu open/close
function handleChevronClick() {
  const subMenu = this.parentElement.nextElementSibling;
  if (subMenu && subMenu.classList.contains("submenu")) {
    subMenu.classList.toggle("mobile-show");
  }
}

// Dynamically add chevrons to sidebar menus and set up their functionality
function initSidebarMenu() {
  document
    .querySelectorAll("#sidebar .menu-item-has-children")
    .forEach((menuItem) => {
      // Create and append chevron
      const chevron = createChevronElement();
      menuItem.appendChild(chevron);

      // Add click event to chevron for toggling submenu
      chevron.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleSubmenu(menuItem, chevron);
      });

      // Show submenu if current menu item is active or has active children
      if (
        menuItem.querySelector(".current-menu-item") ||
        menuItem.classList.contains("current-menu-item")
      ) {
        const subMenu = menuItem.querySelector(".sub-menu");
        if (subMenu) {
          subMenu.classList.add("sub-show");
          chevron.classList.add("chevron-up");
        }
      }
    });
}

// Create a chevron element
function createChevronElement() {
  const chevron = document.createElement("div");
  chevron.innerHTML =
    '<svg width="18px" viewBox="0 0 48 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.64 0.36L24 18.68L42.36 0.36L48 6L24 30L0 6L5.64 0.36Z"/></svg>';
  chevron.style.cursor = "pointer";
  chevron.classList.add("chevron");
  return chevron;
}

// Toggle submenu open/close
function toggleSubmenu(menuItem, chevron) {
  const subMenu = menuItem.querySelector(".sub-menu");
  if (subMenu) {
    subMenu.classList.toggle("sub-show");
    chevron.classList.toggle("chevron-up");
  }
}

function initTabs() {
  const tabContainers = document.querySelectorAll(".st-block-tab");

  // Utility function to show/hide arrows based on scroll position
  function updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow) {
    const maxScrollLeft =
      tabIndicatorsWrapper.scrollWidth - tabIndicatorsWrapper.clientWidth;
    const currentScrollLeft = tabIndicatorsWrapper.scrollLeft;

    backArrow.classList.toggle("hidden", currentScrollLeft <= 0);
    forwardArrow.classList.toggle("hidden", currentScrollLeft >= maxScrollLeft);
  }

  // Utility function to handle scrolling by clicking on arrows
  function scrollTabs(tabIndicatorsWrapper, direction) {
    const scrollAmount = 150;
    tabIndicatorsWrapper.scrollBy({
      left: direction === "forward" ? scrollAmount : -scrollAmount,
      behavior: "smooth",
    });
  }

  // Utility function to activate a specific tab
  function activateTab(tabItems, tabIndicators, index) {
    // Hide all tabs and remove active state from all indicators
    tabItems.forEach((item) => {
      item.classList.add("hide-tab");
      item.classList.remove("show-tab");
    });
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator) =>
      indicator.classList.remove("active-tab")
    );

    // Show the selected tab and activate the corresponding indicator
    tabItems[index].classList.remove("hide-tab");
    tabItems[index].classList.add("show-tab");
    indicatorItems[index].classList.add("active-tab");

    // Scroll the active indicator into view
    // indicatorItems[index].scrollIntoView({
    //   behavior: "smooth",
    //   inline: "center",
    // });
  }

  // Utility function to handle dragging of tab indicators
  function handleDrag(tabIndicatorsWrapper) {
    let isDragging = false;
    let startX, scrollLeft;

    function startDrag(e) {
      isDragging = true;
      tabIndicatorsWrapper.classList.add("scrolling");
      startX = e.pageX || e.touches[0].pageX;
      scrollLeft = tabIndicatorsWrapper.scrollLeft;
    }

    function moveDrag(e) {
      if (!isDragging) return;
      e.preventDefault();
      const x = e.pageX || e.touches[0].pageX;
      const walk = (x - startX) * 2;
      tabIndicatorsWrapper.scrollLeft = scrollLeft - walk;
    }

    function stopDrag() {
      isDragging = false;
      tabIndicatorsWrapper.classList.remove("scrolling");
    }

    tabIndicatorsWrapper.addEventListener("mousedown", startDrag);
    tabIndicatorsWrapper.addEventListener("touchstart", startDrag);
    tabIndicatorsWrapper.addEventListener("mousemove", moveDrag);
    tabIndicatorsWrapper.addEventListener("touchmove", moveDrag);
    tabIndicatorsWrapper.addEventListener("mouseup", stopDrag);
    tabIndicatorsWrapper.addEventListener("mouseleave", stopDrag);
    tabIndicatorsWrapper.addEventListener("touchend", stopDrag);
  }

  // Main loop through each tab block container
  tabContainers.forEach((container) => {
    const tabItems = container.querySelectorAll(".st-block-tab-item");
    const tabIndicators = container.querySelector(".tab-indicators");
    const backArrow = container.querySelector(".tab-back-arrow");
    const forwardArrow = container.querySelector(".tab-forward-arrow");
    const tabIndicatorsWrapper = container.querySelector(
      ".tab-indicators-wrapper"
    );

    if (!tabItems.length || !tabIndicators) return;

    // Attach event listeners to arrows
    backArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "back")
    );
    forwardArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "forward")
    );

    // Attach event listeners to each tab indicator
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator, index) => {
      indicator.addEventListener("click", () =>
        activateTab(tabItems, tabIndicators, index)
      );
    });

    // Initialize tabs and arrows
    activateTab(tabItems, tabIndicators, 0);
    tabItems.forEach((item, index) => {
      if (index !== 0) item.classList.add("hide-tab");
    });

    // Attach drag handling for tab indicators
    handleDrag(tabIndicatorsWrapper);

    // Update arrows initially and on scroll
    tabIndicatorsWrapper.addEventListener("scroll", () =>
      updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow)
    );
    updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow);
  });
}

// Initialize content slider
function initContentSlider() {
  const sliders = document.querySelectorAll(".content-slider-wrapper");

  sliders.forEach((slider) => {
    const container = slider.querySelector(".acf-innerblocks-container");

    // Check if container exists before initializing Swiper
    if (!container) {
      console.warn("Slider container not found in:", slider);
      return;
    }

    // Ensure there are slides to initialize
    const slides = container.children;
    if (!slides.length) {
      console.warn("No slides found in container:", container);
      return;
    }

    // Add Swiper classes to existing elements
    slider.classList.add("swiper");
    container.classList.add("swiper-wrapper");
    Array.from(slides).forEach((slide) => {
      slide.classList.add("swiper-slide");
    });

    const itemsToShowDesktop = parseInt(slider.dataset.itsd, 10) || 3;
    const itemsToShowMobile = parseInt(slider.dataset.itsm, 10) || 2;
    const itemGap = parseInt(slider.dataset.itemgap, 10) || 32;

    // Small delay to ensure DOM is ready
    new Swiper(slider, {
      modules: [Pagination, Autoplay],
      slidesPerView: itemsToShowMobile,
      spaceBetween: itemGap,
      loop: true,
      breakpoints: {
        1024: {
          slidesPerView: itemsToShowDesktop,
        },
        768: {
          slidesPerView: itemsToShowMobile,
        },
      },
      autoHeight: true,
      autoplay: {
        delay: 5000,
        pauseOnMouseEnter: true,
      },
      speed: 600,
      pagination: {
        el: ".swiper-pagination",
        type: "bullets",
        clickable: true,
        dynamicBullets: false,
      },
    });
  });
}

// Observer for dynamically added content
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          if (node.querySelector(".accordion")) {
            initAccordion();
          }
          if (node.querySelector(".st-block-tab")) {
            initTabs();
          }
          if (node.querySelector(".content-slider-wrapper")) {
            initContentSlider();
          }
          if (node.querySelector(".quform-element.star_rating")) {
            initStarRating();
          }
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// Initialize star rating functionality
function initStarRating() {
  const starRatings = document.querySelectorAll('.quform-element.star_rating');
  
  starRatings.forEach(ratingContainer => {
    const options = ratingContainer.querySelectorAll('.quform-option');
    const inputs = ratingContainer.querySelectorAll('.quform-option input');
    
    // Add event listeners to each star
    options.forEach((option, index) => {
      const input = option.querySelector('input');
      const label = option.querySelector('.quform-option-label');
      
      // Hover effect
      label.addEventListener('mouseenter', () => {
        // Fill this star and all stars before it
        for (let i = 0; i <= index; i++) {
          options[i].querySelector('.quform-option-label').classList.add('star-hover');
        }
        
        // Clear stars after this one
        for (let i = index + 1; i < options.length; i++) {
          options[i].querySelector('.quform-option-label').classList.remove('star-hover');
        }
      });
      
      // Handle mouse leave from the entire container
      ratingContainer.addEventListener('mouseleave', () => {
        // Remove hover effect from all stars
        options.forEach(opt => {
          opt.querySelector('.quform-option-label').classList.remove('star-hover');
        });
        
        // Re-apply active state based on checked input
        let checkedIndex = -1;
        inputs.forEach((inp, idx) => {
          if (inp.checked) {
            checkedIndex = idx;
          }
        });
        
        if (checkedIndex >= 0) {
          // Fill stars up to the checked one
          for (let i = 0; i <= checkedIndex; i++) {
            options[i].querySelector('.quform-option-label').classList.add('star-active');
          }
          
          // Clear stars after the checked one
          for (let i = checkedIndex + 1; i < options.length; i++) {
            options[i].querySelector('.quform-option-label').classList.remove('star-active');
          }
        }
      });
      
      // Click effect
      input.addEventListener('change', () => {
        // Remove active class from all stars
        options.forEach(opt => {
          opt.querySelector('.quform-option-label').classList.remove('star-active');
        });
        
        // Add active class to this star and all stars before it
        if (input.checked) {
          for (let i = 0; i <= index; i++) {
            options[i].querySelector('.quform-option-label').classList.add('star-active');
          }
        }
      });
    });
    
    // Initialize the active state based on any pre-selected value
    inputs.forEach((input, index) => {
      if (input.checked) {
        for (let i = 0; i <= index; i++) {
          options[i].querySelector('.quform-option-label').classList.add('star-active');
        }
      }
    });
  });
}

// Initialize course filtering functionality
function initCourseFiltering() {
  const form = document.getElementById('course-filter-form');
  if (!form) return; // Exit if form doesn't exist
  
  const resultsCount = document.getElementById('results-count');
  // Handle form submission with loading indicator
  form.addEventListener('submit', function() {
    showLoadingIndicator();
    // Let the browser submit the form naturally
  });

  // Function to show loading indicator
  function showLoadingIndicator() {
    let loadingOverlay = document.getElementById('loading-overlay');
    if (!loadingOverlay) {
      loadingOverlay = document.createElement('div');
      loadingOverlay.id = 'loading-overlay';
      loadingOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
      loadingOverlay.innerHTML = `
        <div class="bg-white rounded-lg p-8 flex items-center space-x-4">
          <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <span class="text-lg font-medium">Updating results...</span>
        </div>
      `;
      document.body.appendChild(loadingOverlay);
    }
    loadingOverlay.classList.remove('hidden');
  }

  // Update results count if available
  if (resultsCount && window.allCoursesData && Array.isArray(window.allCoursesData)) {
    resultsCount.textContent = `${window.allCoursesData.length} total courses available`;
  }
}

// Initialize publications filtering and pagination
function initPublicationsFiltering() {
  // Check if we're on the research page
  if (!window.publicationsData || !Array.isArray(window.publicationsData)) {
    return;
  }

  const searchInput = document.getElementById('publication-search');
  const typeFilter = document.getElementById('publication-type-filter');
  const yearFilter = document.getElementById('publication-year-filter');
  const itemsPerPageSelect = document.getElementById('items-per-page');
  const clearFiltersBtn = document.getElementById('clear-filters');
  const applyFiltersBtn = document.getElementById('apply-filters');
  const publicationsGrid = document.getElementById('publications-grid');
  const noResults = document.getElementById('no-results');
  const loadingIndicator = document.getElementById('publications-loading');
  const resultsInfo = document.getElementById('results-info');
  const prevPageBtn = document.getElementById('prev-page');
  const nextPageBtn = document.getElementById('next-page');
  const firstPageBtn = document.getElementById('first-page');
  const lastPageBtn = document.getElementById('last-page');
  const paginationList = document.querySelector('#pagination-container ul.pagination');
  const paginationInfo = document.getElementById('pagination-info');

  // Cache SVG HTML for controls so we can reconstruct anchors/spans
  const firstIconHTML = firstPageBtn ? firstPageBtn.innerHTML : '';
  const prevIconHTML = prevPageBtn ? prevPageBtn.innerHTML : '';
  const nextIconHTML = nextPageBtn ? nextPageBtn.innerHTML : '';
  const lastIconHTML = lastPageBtn ? lastPageBtn.innerHTML : '';

  let currentPage = 1;
  let itemsPerPage = 12;
  let filteredPublications = [...window.publicationsData];
  let allPublications = [...window.publicationsData];

  // Initialize year filter options
  function initYearFilter() {
    const years = [...new Set(allPublications.map(pub => pub.year).filter(year => year))].sort((a, b) => b - a);
    yearFilter.innerHTML = '<option value="">All Years</option>';
    years.forEach(year => {
      const option = document.createElement('option');
      option.value = year;
      option.textContent = year;
      yearFilter.appendChild(option);
    });
  }

  // Filter publications based on current filters
  function filterPublications() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const selectedType = typeFilter.value;
    const selectedYear = yearFilter.value;

    filteredPublications = allPublications.filter(pub => {
      // Search filter
      const matchesSearch = !searchTerm || 
        pub.title.toLowerCase().includes(searchTerm) ||
        pub.details.toLowerCase().includes(searchTerm) ||
        pub.year.toString().includes(searchTerm);

      // Type filter
      const matchesType = !selectedType || pub.term_slugs.includes(selectedType);

      // Year filter
      const matchesYear = !selectedYear || pub.year.toString() === selectedYear;

      return matchesSearch && matchesType && matchesYear;
    });

    currentPage = 1; // Reset to first page when filtering
    renderPublications();
  }

  // Create publication HTML
  function createPublicationHTML(pub) {
    const link = pub.link ? `href="${pub.link}" target="_blank"` : '';
    const linkStart = pub.link ? `<a ${link} class="no-underline hover:text-primary-light transition-colors duration-100 ease-in-out">` : '';
    const linkEnd = pub.link ? '</a>' : '';
    
    // Get category colors (you might need to adjust this based on your theme's function)
    const categoryTags = pub.terms.map(term => {
      return `<p class="my-0 inline-block bg-gray-200 text-gray-800 text-xs font-semibold px-2.5 py-0.5 rounded-full uppercase text-nowrap mr-1">${term.name}</p>`;
    }).join('');

    return `
      <div class="rounded-2xl border-gray-200 border border-solid h-full overflow-hidden flex flex-col justify-center">
        <div class="rounded-br-3xl overflow-hidden relative bg-gray-50 p-4 border-gray-200 border border-solid -mx-1 border-t-0 flex flex-col justify-center grow">
          <p class="font-bold text-base m-0 !leading-snug">
            ${linkStart}${pub.title}${linkEnd}
          </p>
          <p class="mb-0 mt-1 text-xs font-bold text-gray-400">${pub.year}</p>
        </div>
        <div class="p-4 pt-4 flex gap-x-4">
          <div class="shrink">
            <p class="text-xs my-0 !leading-snug">${pub.details}</p>
          </div>
          <div class="grow">
            ${categoryTags}
          </div>
        </div>
      </div>
    `;
  }

  // Render publications for current page
  function renderPublications() {
    showLoading(true);

    // Simulate a small delay for better UX
    setTimeout(() => {
      const startIndex = (currentPage - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;
      const publicationsToShow = filteredPublications.slice(startIndex, endIndex);

      // Clear grid
      publicationsGrid.innerHTML = '';

      if (publicationsToShow.length === 0) {
        noResults.classList.remove('hidden');
        publicationsGrid.classList.add('hidden');
      } else {
        noResults.classList.add('hidden');
        publicationsGrid.classList.remove('hidden');
        
        // Add publications to grid
        publicationsToShow.forEach(pub => {
          const publicationElement = document.createElement('div');
          publicationElement.innerHTML = createPublicationHTML(pub);
          publicationsGrid.appendChild(publicationElement.firstElementChild);
        });
      }

      updateResultsInfo();
      updatePagination();
      showLoading(false);
    }, 150);
  }

  // Show/hide loading indicator
  function showLoading(show) {
    if (show) {
      loadingIndicator.classList.remove('hidden');
      publicationsGrid.style.opacity = '0.5';
    } else {
      loadingIndicator.classList.add('hidden');
      publicationsGrid.style.opacity = '1';
    }
  }

  // Update results info
  function updateResultsInfo() {
    const totalResults = filteredPublications.length;
    const startIndex = (currentPage - 1) * itemsPerPage + 1;
    const endIndex = Math.min(currentPage * itemsPerPage, totalResults);
    
    if (!resultsInfo) return;
    if (totalResults === 0) {
      resultsInfo.textContent = 'No results found';
    } else {
      resultsInfo.textContent = `Showing ${startIndex}-${endIndex} of ${totalResults} publications`;
    }
  }

  // Update pagination controls
  function updatePagination() {
    const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);

    // Update pagination info (optional element)
    if (paginationInfo) {
      paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    }

    if (!paginationList) return;

    // Enable/disable first/prev/next/last and swap anchors<->spans to match CSS
    const prevLi = paginationList.querySelector('li.prev');
    const nextLi = paginationList.querySelector('li.next');
    const firstLi = paginationList.querySelector('li.first');
    const lastLi = paginationList.querySelector('li.last');

    setControlState(firstLi, 'first-page', firstIconHTML, currentPage === 1 || totalPages === 0);
    setControlState(prevLi, 'prev-page', prevIconHTML, currentPage === 1 || totalPages === 0);
    setControlState(nextLi, 'next-page', nextIconHTML, currentPage === totalPages || totalPages === 0);
    setControlState(lastLi, 'last-page', lastIconHTML, currentPage === totalPages || totalPages === 0);

    // Remove existing page items
    paginationList.querySelectorAll('li.pages, li.pages.current').forEach((li) => li.remove());

    if (totalPages <= 1) return;

    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    // Helper to insert before nextLi
    const insertBeforeNext = (li) => {
      if (nextLi) {
        paginationList.insertBefore(li, nextLi);
      } else {
        paginationList.appendChild(li);
      }
    };

    // First page and ellipsis
    if (startPage > 1) {
      insertBeforeNext(createPageLi(1));
      if (startPage > 2) {
        insertBeforeNext(createDotsLi());
      }
    }

    // Visible page numbers
    for (let i = startPage; i <= endPage; i++) {
      insertBeforeNext(createPageLi(i));
    }

    // Ellipsis and last page
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        insertBeforeNext(createDotsLi());
      }
      insertBeforeNext(createPageLi(totalPages));
    }

    // Reattach listeners after any control swaps
    attachPaginationListeners();
  }

  // Swap anchors and spans for disabled/enabled state on controls
  function setControlState(li, anchorId, iconHTML, disabled) {
    if (!li) return;
    const existingAnchor = li.querySelector('a#' + anchorId);
    const existingSpan = li.querySelector('span');
    if (disabled) {
      li.classList.add('disabled');
      if (existingAnchor) {
        const span = document.createElement('span');
        span.innerHTML = iconHTML || existingAnchor.innerHTML;
        existingAnchor.replaceWith(span);
      }
    } else {
      li.classList.remove('disabled');
      if (!existingAnchor) {
        const a = document.createElement('a');
        a.id = anchorId;
        a.href = '#';
        a.innerHTML = iconHTML || (existingSpan ? existingSpan.innerHTML : '');
        if (existingSpan) {
          existingSpan.replaceWith(a);
        } else {
          li.appendChild(a);
        }
      }
    }
  }

  function attachPaginationListeners() {
    const newPrev = document.getElementById('prev-page');
    const newNext = document.getElementById('next-page');
    const newFirst = document.getElementById('first-page');
    const newLast = document.getElementById('last-page');

    if (newPrev) {
      newPrev.onclick = (e) => {
        e.preventDefault();
        if (currentPage > 1) {
          currentPage--;
          renderPublications();
        }
      };
    }
    if (newNext) {
      newNext.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (currentPage < totalPages) {
          currentPage++;
          renderPublications();
        }
      };
    }
    if (newFirst) {
      newFirst.onclick = (e) => {
        e.preventDefault();
        if (currentPage !== 1) {
          currentPage = 1;
          renderPublications();
        }
      };
    }
    if (newLast) {
      newLast.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (totalPages > 0 && currentPage !== totalPages) {
          currentPage = totalPages;
          renderPublications();
        }
      };
    }
  }

  // Create a page <li> matching partial pagination styles
  function createPageLi(pageNum) {
    const li = document.createElement('li');
    li.className = 'pages' + (pageNum === currentPage ? ' current' : '');
    if (pageNum === currentPage) {
      const span = document.createElement('span');
      span.textContent = pageNum;
      li.appendChild(span);
    } else {
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = pageNum;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        currentPage = pageNum;
        renderPublications();
      });
      li.appendChild(a);
    }
    return li;
  }

  // Add ellipsis
  function createDotsLi() {
    const li = document.createElement('li');
    li.className = 'pages current';
    const span = document.createElement('span');
    span.className = 'dots';
    span.textContent = '...';
    li.appendChild(span);
    return li;
  }

  // Clear all filters
  function clearFilters() {
    searchInput.value = '';
    typeFilter.value = '';
    yearFilter.value = '';
    itemsPerPageSelect.value = '12';
    itemsPerPage = 12;
    filterPublications();
  }

  // Event listeners
  searchInput.addEventListener('input', debounce(filterPublications, 300));
  typeFilter.addEventListener('change', filterPublications);
  yearFilter.addEventListener('change', filterPublications);
  
  itemsPerPageSelect.addEventListener('change', (e) => {
    itemsPerPage = parseInt(e.target.value);
    currentPage = 1;
    renderPublications();
  });
  
  clearFiltersBtn.addEventListener('click', clearFilters);
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', () => {
      filterPublications();
      // Optionally scroll to results
      const gridTop = publicationsGrid?.getBoundingClientRect().top + window.scrollY - 100;
      if (!isNaN(gridTop)) {
        window.scrollTo({ top: gridTop, behavior: 'smooth' });
      }
    });
  }
  
  prevPageBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage > 1) {
      currentPage--;
      renderPublications();
    }
  });
  
  nextPageBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
    if (currentPage < totalPages) {
      currentPage++;
      renderPublications();
    }
  });

  if (firstPageBtn) {
    firstPageBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (currentPage !== 1) {
        currentPage = 1;
        renderPublications();
      }
    });
  }

  if (lastPageBtn) {
    lastPageBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
      if (totalPages > 0 && currentPage !== totalPages) {
        currentPage = totalPages;
        renderPublications();
      }
    });
  }

  // Debounce function for search input
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Initialize
  initYearFilter();
  renderPublications();
}

// Initialize home redirect form functionality
function initHomeRedirectForm() {
  const form = document.getElementById('home-redirect-form');
  if (!form) return;

  const firstSelect = document.getElementById('first-select');
  const secondSelect = document.getElementById('second-select');
  const secondSelectGroup = document.getElementById('second-select-group');
  const submitButton = document.getElementById('submit-button');
  const formDataScript = document.getElementById('home-form-data');

  if (!firstSelect || !secondSelect || !formDataScript) return;

  let formData;
  try {
    formData = JSON.parse(formDataScript.textContent);
  } catch (e) {
    console.error('Failed to parse home form data:', e);
    return;
  }

  // Handle first select change
  firstSelect.addEventListener('change', handleFirstSelectChange);
  
  // Handle second select change
  secondSelect.addEventListener('change', handleSecondSelectChange);
  
  // Handle form submission
  form.addEventListener('submit', handleFormSubmit);

  function handleFirstSelectChange(event) {
    const selectedIndex = parseInt(event.target.value);
    
    // Reset second select
    secondSelect.innerHTML = '<option value="">Choose...</option>';
    secondSelect.disabled = true;
    submitButton.disabled = true;

    if (selectedIndex >= 0 && formData.options[selectedIndex]) {
      const secondOptions = formData.options[selectedIndex].secondOptions;
      
      if (secondOptions && secondOptions.length > 0) {
        // Populate second select
        secondOptions.forEach((option, index) => {
          const optionElement = document.createElement('option');
          optionElement.value = option.url;
          optionElement.textContent = option.label;
          secondSelect.appendChild(optionElement);
        });
        
        // Enable second select
        secondSelect.disabled = false;
      }
    }
  }

  function handleSecondSelectChange(event) {
    if (event.target.value) {
      submitButton.disabled = false;
    } else {
      submitButton.disabled = true;
    }
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    
    const selectedUrl = secondSelect.value;
    if (selectedUrl) {
      window.location.href = selectedUrl;
    }
  }
}

// Initialize everything on window load
window.addEventListener("load", () => {
  initAccordion();
  initMobileMenu();
  initSidebarMenu();
  handleSubmenuToggle();
  initTabs();
  initContentSlider();
  initStarRating();
  initCourseFiltering();
  initPublicationsFiltering();

  // Reapply submenu toggle on window resize
  window.addEventListener("resize", handleSubmenuToggle);

  // Setup observer to watch for dynamically added content
  setupMutationObserver();

  // Initialize home redirect form
  initHomeRedirectForm();
});
