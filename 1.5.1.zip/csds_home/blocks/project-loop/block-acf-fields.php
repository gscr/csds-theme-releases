<?php

acf_add_local_field_group([
    'key' => 'group_project_loop',
    'title' => 'Project Loop Settings',
    'fields' => [
        [
            'key' => 'field_project_posts_per_page',
            'label' => 'Projects Per Page',
            'name' => 'posts_per_page',
            'type' => 'number',
            'instructions' => 'Enter the number of projects to display',
            'required' => 1,
            'default_value' => 6,
            'min' => 3,
            'max' => 12,
        ],
        [
            'key' => 'field_project_posts_offset',
            'label' => 'Projects Offset',
            'name' => 'posts_offset',
            'type' => 'number',
            'instructions' => 'Skip this many projects from the beginning (0 = start from first project)',
            'required' => 0,
            'default_value' => 0,
            'min' => 0,
            'max' => 100,
        ],
        [
            'key' => 'field_project_show_more_button',
            'label' => 'Show "More Projects" Button',
            'name' => 'show_more_button',
            'type' => 'true_false',
            'instructions' => 'Enable to display a "More Projects" button at the bottom',
            'default_value' => 1,
            'ui' => 1,
        ],
        [
            'key' => 'field_project_button_text',
            'label' => 'Button Text',
            'name' => 'button_text',
            'type' => 'link',
            'instructions' => 'Enter the text and link for the "More Projects" button',
            'required' => 0,
            'conditional_logic' => [
                [
                    [
                        'field' => 'field_project_show_more_button',
                        'operator' => '==',
                        'value' => '1',
                    ]
                ]
            ],
            'return_format' => 'array',
        ],
        [
            'key' => 'field_project_description_max_chars',
            'label' => 'Short Description Character Limit',
            'name' => 'description_max_chars',
            'type' => 'number',
            'instructions' => 'Maximum number of characters to display for project short descriptions. Leave empty for no limit.',
            'required' => 0,
            'default_value' => '',
            'min' => 50,
            'max' => 500,
            'placeholder' => 'e.g. 150',
        ],
    ],
    'location' => [
        [
            [
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/project-loop',
            ],
        ],
    ],
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
]);
