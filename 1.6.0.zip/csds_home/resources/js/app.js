import Swiper from "swiper";
import { Pagination, Autoplay } from "swiper/modules";

// Initialize accordion functionality
function initAccordion() {
  document.querySelectorAll("[data-accordion-toggle]").forEach((toggle) => {
    toggle.removeEventListener("click", handleAccordionToggle);
    toggle.addEventListener("click", handleAccordionToggle);
  });
}

// Toggle accordion open/close
function handleAccordionToggle(event) {
  const toggle = event.currentTarget;
  const content = toggle.nextElementSibling;
  const chevron = toggle.querySelector(".chevron");

  if (content.classList.contains("max-h-0")) {
    content.classList.remove("max-h-0");
    content.classList.add("max-h-full");
    chevron.classList.add("rotate-180");
  } else {
    content.classList.remove("max-h-full");
    content.classList.add("max-h-0");
    chevron.classList.remove("rotate-180");
  }
}

// Initialise mobile menu toggle
function initMobileMenu() {
  const mainNavigation = document.querySelector("#primary-menu");
  const menuToggle = document.querySelector("#primary-menu-toggle");

  if (mainNavigation && menuToggle) {
    menuToggle.addEventListener("click", (e) => {
      e.preventDefault();
      mainNavigation.classList.toggle("hidden");
    });
  }
}

// Handle chevron click for submenus
function handleSubmenuToggle() {
  document.querySelectorAll("#primary-menu .chevron").forEach((chevron) => {
    chevron.removeEventListener("click", handleChevronClick);
    if (window.innerWidth <= 959) {
      chevron.addEventListener("click", handleChevronClick);
    }
  });
}

// Toggle submenu open/close
function handleChevronClick() {
  const subMenu = this.parentElement.nextElementSibling;
  if (subMenu && subMenu.classList.contains("submenu")) {
    subMenu.classList.toggle("mobile-show");
  }
}

// Dynamically add chevrons to sidebar menus and set up their functionality
function initSidebarMenu() {
  document
    .querySelectorAll("#sidebar .menu-item-has-children")
    .forEach((menuItem) => {
      // Create and append chevron
      const chevron = createChevronElement();
      menuItem.appendChild(chevron);

      // Add click event to chevron for toggling submenu
      chevron.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleSubmenu(menuItem, chevron);
      });

      // Show submenu if current menu item is active or has active children
      if (
        menuItem.querySelector(".current-menu-item") ||
        menuItem.classList.contains("current-menu-item")
      ) {
        const subMenu = menuItem.querySelector(".sub-menu");
        if (subMenu) {
          subMenu.classList.add("sub-show");
          chevron.classList.add("chevron-up");
        }
      }
    });
}

// Create a chevron element
function createChevronElement() {
  const chevron = document.createElement("div");
  chevron.innerHTML =
    '<svg width="18px" viewBox="0 0 48 30" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.64 0.36L24 18.68L42.36 0.36L48 6L24 30L0 6L5.64 0.36Z"/></svg>';
  chevron.style.cursor = "pointer";
  chevron.classList.add("chevron");
  return chevron;
}

// Toggle submenu open/close
function toggleSubmenu(menuItem, chevron) {
  const subMenu = menuItem.querySelector(".sub-menu");
  if (subMenu) {
    subMenu.classList.toggle("sub-show");
    chevron.classList.toggle("chevron-up");
  }
}

function initTabs() {
  const tabContainers = document.querySelectorAll(".st-block-tab");

  // Utility function to show/hide arrows based on scroll position
  function updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow) {
    const maxScrollLeft =
      tabIndicatorsWrapper.scrollWidth - tabIndicatorsWrapper.clientWidth;
    const currentScrollLeft = tabIndicatorsWrapper.scrollLeft;

    backArrow.classList.toggle("hidden", currentScrollLeft <= 0);
    forwardArrow.classList.toggle("hidden", currentScrollLeft >= maxScrollLeft);
  }

  // Utility function to handle scrolling by clicking on arrows
  function scrollTabs(tabIndicatorsWrapper, direction) {
    const scrollAmount = 150;
    tabIndicatorsWrapper.scrollBy({
      left: direction === "forward" ? scrollAmount : -scrollAmount,
      behavior: "smooth",
    });
  }

  // Utility function to activate a specific tab
  function activateTab(tabItems, tabIndicators, index) {
    // Hide all tabs and remove active state from all indicators
    tabItems.forEach((item) => {
      item.classList.add("hide-tab");
      item.classList.remove("show-tab");
    });
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator) =>
      indicator.classList.remove("active-tab")
    );

    // Show the selected tab and activate the corresponding indicator
    tabItems[index].classList.remove("hide-tab");
    tabItems[index].classList.add("show-tab");
    indicatorItems[index].classList.add("active-tab");

    // Scroll the active indicator into view
    // indicatorItems[index].scrollIntoView({
    //   behavior: "smooth",
    //   inline: "center",
    // });
  }

  // Utility function to handle dragging of tab indicators
  function handleDrag(tabIndicatorsWrapper) {
    let isDragging = false;
    let startX, scrollLeft;

    function startDrag(e) {
      isDragging = true;
      tabIndicatorsWrapper.classList.add("scrolling");
      startX = e.pageX || e.touches[0].pageX;
      scrollLeft = tabIndicatorsWrapper.scrollLeft;
    }

    function moveDrag(e) {
      if (!isDragging) return;
      e.preventDefault();
      const x = e.pageX || e.touches[0].pageX;
      const walk = (x - startX) * 2;
      tabIndicatorsWrapper.scrollLeft = scrollLeft - walk;
    }

    function stopDrag() {
      isDragging = false;
      tabIndicatorsWrapper.classList.remove("scrolling");
    }

    tabIndicatorsWrapper.addEventListener("mousedown", startDrag);
    tabIndicatorsWrapper.addEventListener("touchstart", startDrag);
    tabIndicatorsWrapper.addEventListener("mousemove", moveDrag);
    tabIndicatorsWrapper.addEventListener("touchmove", moveDrag);
    tabIndicatorsWrapper.addEventListener("mouseup", stopDrag);
    tabIndicatorsWrapper.addEventListener("mouseleave", stopDrag);
    tabIndicatorsWrapper.addEventListener("touchend", stopDrag);
  }

  // Main loop through each tab block container
  tabContainers.forEach((container) => {
    const tabItems = container.querySelectorAll(".st-block-tab-item");
    const tabIndicators = container.querySelector(".tab-indicators");
    const backArrow = container.querySelector(".tab-back-arrow");
    const forwardArrow = container.querySelector(".tab-forward-arrow");
    const tabIndicatorsWrapper = container.querySelector(
      ".tab-indicators-wrapper"
    );

    if (!tabItems.length || !tabIndicators) return;

    // Attach event listeners to arrows
    backArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "back")
    );
    forwardArrow.addEventListener("click", () =>
      scrollTabs(tabIndicatorsWrapper, "forward")
    );

    // Attach event listeners to each tab indicator
    const indicatorItems = tabIndicators.querySelectorAll(".tab-indicator");
    indicatorItems.forEach((indicator, index) => {
      indicator.addEventListener("click", () =>
        activateTab(tabItems, tabIndicators, index)
      );
    });

    // Initialize tabs and arrows
    activateTab(tabItems, tabIndicators, 0);
    tabItems.forEach((item, index) => {
      if (index !== 0) item.classList.add("hide-tab");
    });

    // Attach drag handling for tab indicators
    handleDrag(tabIndicatorsWrapper);

    // Update arrows initially and on scroll
    tabIndicatorsWrapper.addEventListener("scroll", () =>
      updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow)
    );
    updateArrows(tabIndicatorsWrapper, backArrow, forwardArrow);
  });
}

// Initialize content slider
function initContentSlider() {
  const sliders = document.querySelectorAll(".content-slider-wrapper");

  sliders.forEach((slider) => {
    const container = slider.querySelector(".acf-innerblocks-container");

    // Check if container exists before initializing Swiper
    if (!container) {
      console.warn("Slider container not found in:", slider);
      return;
    }

    // Ensure there are slides to initialize
    const slides = container.children;
    if (!slides.length) {
      console.warn("No slides found in container:", container);
      return;
    }

    // Add Swiper classes to existing elements
    slider.classList.add("swiper");
    container.classList.add("swiper-wrapper");
    Array.from(slides).forEach((slide) => {
      slide.classList.add("swiper-slide");
    });

    const itemsToShowDesktop = parseInt(slider.dataset.itsd, 10) || 3;
    const itemsToShowMobile = parseInt(slider.dataset.itsm, 10) || 2;
    const itemGap = parseInt(slider.dataset.itemgap, 10) || 32;

    // Small delay to ensure DOM is ready
    new Swiper(slider, {
      modules: [Pagination, Autoplay],
      slidesPerView: itemsToShowMobile,
      spaceBetween: itemGap,
      loop: true,
      breakpoints: {
        1024: {
          slidesPerView: itemsToShowDesktop,
        },
        768: {
          slidesPerView: itemsToShowMobile,
        },
      },
      autoHeight: true,
      autoplay: {
        delay: 5000,
        pauseOnMouseEnter: true,
      },
      speed: 600,
      pagination: {
        el: ".swiper-pagination",
        type: "bullets",
        clickable: true,
        dynamicBullets: false,
      },
    });
  });
}

// Observer for dynamically added content
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          if (node.querySelector(".accordion")) {
            initAccordion();
          }
          if (node.querySelector(".st-block-tab")) {
            initTabs();
          }
          if (node.querySelector(".content-slider-wrapper")) {
            initContentSlider();
          }
          if (node.querySelector(".quform-element.star_rating")) {
            initStarRating();
          }
          if (node.querySelector("#search-type-toggle") || node.querySelector("#main-search-form")) {
            initSearchTypeToggle();
          }
          if (node.querySelector(".resource-loop")) {
            initResourceFilter();
          }
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// Initialize star rating functionality
function initStarRating() {
  const starRatings = document.querySelectorAll('.quform-element.star_rating');
  
  starRatings.forEach(ratingContainer => {
    const options = ratingContainer.querySelectorAll('.quform-option');
    const inputs = ratingContainer.querySelectorAll('.quform-option input');
    
    // Add event listeners to each star
    options.forEach((option, index) => {
      const input = option.querySelector('input');
      const label = option.querySelector('.quform-option-label');
      
      // Hover effect
      label.addEventListener('mouseenter', () => {
        // Fill this star and all stars before it
        for (let i = 0; i <= index; i++) {
          options[i].querySelector('.quform-option-label').classList.add('star-hover');
        }
        
        // Clear stars after this one
        for (let i = index + 1; i < options.length; i++) {
          options[i].querySelector('.quform-option-label').classList.remove('star-hover');
        }
      });
      
      // Handle mouse leave from the entire container
      ratingContainer.addEventListener('mouseleave', () => {
        // Remove hover effect from all stars
        options.forEach(opt => {
          opt.querySelector('.quform-option-label').classList.remove('star-hover');
        });
        
        // Re-apply active state based on checked input
        let checkedIndex = -1;
        inputs.forEach((inp, idx) => {
          if (inp.checked) {
            checkedIndex = idx;
          }
        });
        
        if (checkedIndex >= 0) {
          // Fill stars up to the checked one
          for (let i = 0; i <= checkedIndex; i++) {
            options[i].querySelector('.quform-option-label').classList.add('star-active');
          }
          
          // Clear stars after the checked one
          for (let i = checkedIndex + 1; i < options.length; i++) {
            options[i].querySelector('.quform-option-label').classList.remove('star-active');
          }
        }
      });
      
      // Click effect
      input.addEventListener('change', () => {
        // Remove active class from all stars
        options.forEach(opt => {
          opt.querySelector('.quform-option-label').classList.remove('star-active');
        });
        
        // Add active class to this star and all stars before it
        if (input.checked) {
          for (let i = 0; i <= index; i++) {
            options[i].querySelector('.quform-option-label').classList.add('star-active');
          }
        }
      });
    });
    
    // Initialize the active state based on any pre-selected value
    inputs.forEach((input, index) => {
      if (input.checked) {
        for (let i = 0; i <= index; i++) {
          options[i].querySelector('.quform-option-label').classList.add('star-active');
        }
      }
    });
  });
}

// Initialize course filtering functionality
function initCourseFiltering() {
  const form = document.getElementById('course-filter-form');
  if (!form) return; // Exit if form doesn't exist
  
  const resultsCount = document.getElementById('results-count');
  // Handle form submission with loading indicator
  form.addEventListener('submit', function() {
    showLoadingIndicator();
    // Let the browser submit the form naturally
  });

  // Function to show loading indicator
  function showLoadingIndicator() {
    let loadingOverlay = document.getElementById('loading-overlay');
    if (!loadingOverlay) {
      loadingOverlay = document.createElement('div');
      loadingOverlay.id = 'loading-overlay';
      loadingOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
      loadingOverlay.innerHTML = `
        <div class="bg-white rounded-lg p-8 flex items-center space-x-4">
          <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <span class="text-lg font-medium">Updating results...</span>
        </div>
      `;
      document.body.appendChild(loadingOverlay);
    }
    loadingOverlay.classList.remove('hidden');
  }

  // Update results count if available
  if (resultsCount && window.allCoursesData && Array.isArray(window.allCoursesData)) {
    resultsCount.textContent = `${window.allCoursesData.length} total courses available`;
  }
}

// Initialize publications filtering and pagination
function initPublicationsFiltering() {
  // Check if we're on the research page
  if (!window.publicationsData || !Array.isArray(window.publicationsData)) {
    return;
  }

  const searchInput = document.getElementById('publication-search');
  const typeFilter = document.getElementById('publication-type-filter');
  const yearFilter = document.getElementById('publication-year-filter');
  const itemsPerPageSelect = document.getElementById('items-per-page');
  const clearFiltersBtn = document.getElementById('clear-filters');
  const applyFiltersBtn = document.getElementById('apply-filters');
  const publicationsGrid = document.getElementById('publications-grid');
  const noResults = document.getElementById('no-results');
  const loadingIndicator = document.getElementById('publications-loading');
  const resultsInfo = document.getElementById('results-info');
  const prevPageBtn = document.getElementById('prev-page');
  const nextPageBtn = document.getElementById('next-page');
  const firstPageBtn = document.getElementById('first-page');
  const lastPageBtn = document.getElementById('last-page');
  const paginationList = document.querySelector('#pagination-container ul.pagination');
  const paginationMobile = document.querySelector('#pagination-container .sm\\:hidden');
  const paginationMobilePages = document.getElementById('pagination-pages-mobile');
  const paginationInfo = document.getElementById('pagination-info');

  // Cache SVG HTML for controls so we can reconstruct anchors/spans
  const firstIconHTML = firstPageBtn ? firstPageBtn.innerHTML : '';
  const prevIconHTML = prevPageBtn ? prevPageBtn.innerHTML : '';
  const nextIconHTML = nextPageBtn ? nextPageBtn.innerHTML : '';
  const lastIconHTML = lastPageBtn ? lastPageBtn.innerHTML : '';

  let currentPage = 1;
  let itemsPerPage = 12;
  let filteredPublications = [...window.publicationsData];
  let allPublications = [...window.publicationsData];

  // Initialize year filter options
  function initYearFilter() {
    const years = [...new Set(allPublications.map(pub => pub.year).filter(year => year))].sort((a, b) => b - a);
    yearFilter.innerHTML = '<option value="">All Years</option>';
    years.forEach(year => {
      const option = document.createElement('option');
      option.value = year;
      option.textContent = year;
      yearFilter.appendChild(option);
    });
  }

  // Filter publications based on current filters
  function filterPublications() {
    try {
      const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
      const selectedType = typeFilter ? typeFilter.value : '';
      const selectedYear = yearFilter ? yearFilter.value : '';

      filteredPublications = allPublications.filter(pub => {
        // Search filter
        const matchesSearch = !searchTerm || 
          (pub.title && pub.title.toLowerCase().includes(searchTerm)) ||
          (pub.details && pub.details.toLowerCase().includes(searchTerm)) ||
          (pub.year && pub.year.toString().includes(searchTerm));

        // Type filter
        const matchesType = !selectedType || (pub.term_slugs && pub.term_slugs.includes(selectedType));

        // Year filter
        const matchesYear = !selectedYear || (pub.year && pub.year.toString() === selectedYear);

        return matchesSearch && matchesType && matchesYear;
      });

      currentPage = 1; // Reset to first page when filtering
      renderPublications();
    } catch (error) {
      console.error('Error filtering publications:', error);
      // Ensure loading indicator is hidden even if filtering fails
      showLoading(false);
    }
  }

  // Create publication HTML
  function createPublicationHTML(pub) {
    const link = pub.link ? `href="${pub.link}" target="_blank"` : '';
    const linkStart = pub.link ? `<a ${link} class="no-underline hover:text-primary-light transition-colors duration-100 ease-in-out">` : '';
    const linkEnd = pub.link ? '</a>' : '';
    
    // Get category colors (you might need to adjust this based on your theme's function)
    const categoryTags = pub.terms.map(term => {
      return `<p class="my-0 inline-block bg-gray-200 text-gray-800 text-xs font-semibold px-2.5 py-0.5 rounded-full uppercase text-nowrap mr-1">${term.name}</p>`;
    }).join('');

    return `
      <div class="rounded-2xl border-gray-200 border border-solid h-full overflow-hidden flex flex-col justify-center">
        <div class="rounded-br-3xl overflow-hidden relative bg-gray-50 p-4 border-gray-200 border border-solid -mx-1 border-t-0 flex flex-col justify-center grow">
          <p class="font-bold text-base m-0 !leading-snug">
            ${linkStart}${pub.title}${linkEnd}
          </p>
          <p class="mb-0 mt-1 text-xs font-bold text-gray-400">${pub.year}</p>
        </div>
        <div class="p-4 pt-4 flex gap-x-4">
          <div class="shrink">
            <p class="text-xs my-0 !leading-snug">${pub.details}</p>
          </div>
          <div class="grow">
            ${categoryTags}
          </div>
        </div>
      </div>
    `;
  }

  // Render publications for current page
  function renderPublications() {
    showLoading(true);

    // Simulate a small delay for better UX
    setTimeout(() => {
      try {
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const publicationsToShow = filteredPublications.slice(startIndex, endIndex);

        // Clear grid
        if (publicationsGrid) {
          publicationsGrid.innerHTML = '';
        }

        if (publicationsToShow.length === 0) {
          if (noResults) noResults.classList.remove('hidden');
          if (publicationsGrid) publicationsGrid.classList.add('hidden');
        } else {
          if (noResults) noResults.classList.add('hidden');
          if (publicationsGrid) publicationsGrid.classList.remove('hidden');
          
          // Add publications to grid
          publicationsToShow.forEach(pub => {
            const publicationElement = document.createElement('div');
            publicationElement.innerHTML = createPublicationHTML(pub);
            if (publicationsGrid) {
              publicationsGrid.appendChild(publicationElement.firstElementChild);
            }
          });
        }

        updateResultsInfo();
        updatePagination();
      } catch (error) {
        console.error('Error rendering publications:', error);
      } finally {
        // Always hide loading indicator
        showLoading(false);
      }
    }, 150);
  }

  // Show/hide loading indicator
  function showLoading(show) {
    if (show) {
      if (loadingIndicator) {
        loadingIndicator.classList.remove('hidden');
      }
      if (publicationsGrid) {
        publicationsGrid.style.opacity = '0.5';
      }
    } else {
      if (loadingIndicator) {
        loadingIndicator.classList.add('hidden');
      }
      if (publicationsGrid) {
        publicationsGrid.style.opacity = '1';
      }
    }
  }

  // Update results info
  function updateResultsInfo() {
    const totalResults = filteredPublications.length;
    const startIndex = (currentPage - 1) * itemsPerPage + 1;
    const endIndex = Math.min(currentPage * itemsPerPage, totalResults);
    
    if (!resultsInfo) return;
    if (totalResults === 0) {
      resultsInfo.textContent = 'No results found';
    } else {
      resultsInfo.textContent = `Showing ${startIndex}-${endIndex} of ${totalResults} publications`;
    }
  }

  // Update pagination controls
  function updatePagination() {
    const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);

    // Update pagination info (optional element)
    if (paginationInfo) {
      paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    }

    if (!paginationList) return;

    // Enable/disable first/prev/next/last and swap anchors<->spans to match CSS
    const prevLi = paginationList.querySelector('li.prev');
    const nextLi = paginationList.querySelector('li.next');
    const firstLi = paginationList.querySelector('li.first');
    const lastLi = paginationList.querySelector('li.last');

    setControlState(firstLi, 'first-page', firstIconHTML, currentPage === 1 || totalPages === 0);
    setControlState(prevLi, 'prev-page', prevIconHTML, currentPage === 1 || totalPages === 0);
    setControlState(nextLi, 'next-page', nextIconHTML, currentPage === totalPages || totalPages === 0);
    setControlState(lastLi, 'last-page', lastIconHTML, currentPage === totalPages || totalPages === 0);

    // Update mobile controls if they exist
    if (paginationMobile) {
      const firstMobile = paginationMobile.querySelector('div.first');
      const prevMobile = paginationMobile.querySelector('div.prev');
      const nextMobile = paginationMobile.querySelector('div.next');
      const lastMobile = paginationMobile.querySelector('div.last');
      
      setMobileControlState(firstMobile, 'first-page-mobile', firstIconHTML, currentPage === 1 || totalPages === 0);
      setMobileControlState(prevMobile, 'prev-page-mobile', prevIconHTML, currentPage === 1 || totalPages === 0);
      setMobileControlState(nextMobile, 'next-page-mobile', nextIconHTML, currentPage === totalPages || totalPages === 0);
      setMobileControlState(lastMobile, 'last-page-mobile', lastIconHTML, currentPage === totalPages || totalPages === 0);
    }

    // Remove existing page items from desktop
    paginationList.querySelectorAll('li.pages, li.pages.current').forEach((li) => li.remove());
    
    // Clear mobile pages
    if (paginationMobilePages) {
      paginationMobilePages.innerHTML = '';
    }

    if (totalPages <= 1) {
      // Still show page 1 if there's exactly 1 page
      if (totalPages === 1) {
        insertBeforeNext(createPageLi(1));
        addToMobile(1);
      }
      return;
    }

    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    // Helper to insert before nextLi
    const insertBeforeNext = (li) => {
      if (nextLi) {
        paginationList.insertBefore(li, nextLi);
      } else {
        paginationList.appendChild(li);
      }
    };

    // First page and ellipsis
    if (startPage > 1) {
      insertBeforeNext(createPageLi(1));
      addToMobile(1);
      if (startPage > 2) {
        insertBeforeNext(createDotsLi());
        addToMobile(null, true);
      }
    }

    // Visible page numbers
    for (let i = startPage; i <= endPage; i++) {
      insertBeforeNext(createPageLi(i));
      addToMobile(i);
    }

    // Ellipsis and last page
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        insertBeforeNext(createDotsLi());
        addToMobile(null, true);
      }
      insertBeforeNext(createPageLi(totalPages));
      addToMobile(totalPages);
    }

    // Reattach listeners after any control swaps
    attachPaginationListeners();
  }

  // Swap anchors and spans for disabled/enabled state on controls
  function setControlState(li, anchorId, iconHTML, disabled) {
    if (!li) return;
    const existingAnchor = li.querySelector('a#' + anchorId);
    const existingSpan = li.querySelector('span');
    if (disabled) {
      li.classList.add('disabled');
      if (existingAnchor) {
        const span = document.createElement('span');
        span.innerHTML = iconHTML || existingAnchor.innerHTML;
        existingAnchor.replaceWith(span);
      }
    } else {
      li.classList.remove('disabled');
      if (!existingAnchor) {
        const a = document.createElement('a');
        a.id = anchorId;
        a.href = '#';
        a.innerHTML = iconHTML || (existingSpan ? existingSpan.innerHTML : '');
        if (existingSpan) {
          existingSpan.replaceWith(a);
        } else {
          li.appendChild(a);
        }
      }
    }
  }

  function attachPaginationListeners() {
    const newPrev = document.getElementById('prev-page');
    const newNext = document.getElementById('next-page');
    const newFirst = document.getElementById('first-page');
    const newLast = document.getElementById('last-page');
    
    // Mobile controls
    const newPrevMobile = document.getElementById('prev-page-mobile');
    const newNextMobile = document.getElementById('next-page-mobile');
    const newFirstMobile = document.getElementById('first-page-mobile');
    const newLastMobile = document.getElementById('last-page-mobile');

    // Desktop controls - remove existing listeners first
    if (newPrev) {
      newPrev.onclick = null;
      newPrev.onclick = (e) => {
        e.preventDefault();
        if (currentPage > 1) {
          currentPage--;
          renderPublications();
        }
      };
    }
    if (newNext) {
      newNext.onclick = null;
      newNext.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (currentPage < totalPages) {
          currentPage++;
          renderPublications();
        }
      };
    }
    if (newFirst) {
      newFirst.onclick = null;
      newFirst.onclick = (e) => {
        e.preventDefault();
        if (currentPage !== 1) {
          currentPage = 1;
          renderPublications();
        }
      };
    }
    if (newLast) {
      newLast.onclick = null;
      newLast.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (totalPages > 0 && currentPage !== totalPages) {
          currentPage = totalPages;
          renderPublications();
        }
      };
    }
    
    // Mobile controls - remove existing listeners first
    if (newPrevMobile) {
      newPrevMobile.onclick = null;
      newPrevMobile.onclick = (e) => {
        e.preventDefault();
        if (currentPage > 1) {
          currentPage--;
          renderPublications();
        }
      };
    }
    if (newNextMobile) {
      newNextMobile.onclick = null;
      newNextMobile.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (currentPage < totalPages) {
          currentPage++;
          renderPublications();
        }
      };
    }
    if (newFirstMobile) {
      newFirstMobile.onclick = null;
      newFirstMobile.onclick = (e) => {
        e.preventDefault();
        if (currentPage !== 1) {
          currentPage = 1;
          renderPublications();
        }
      };
    }
    if (newLastMobile) {
      newLastMobile.onclick = null;
      newLastMobile.onclick = (e) => {
        e.preventDefault();
        const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
        if (totalPages > 0 && currentPage !== totalPages) {
          currentPage = totalPages;
          renderPublications();
        }
      };
    }
  }

  // Helper to add pages to mobile pagination
  function addToMobile(pageNum, isDots = false) {
    if (paginationMobilePages) {
      if (isDots) {
        paginationMobilePages.appendChild(createDotsDiv());
      } else {
        paginationMobilePages.appendChild(createPageDiv(pageNum));
      }
    }
  }

  // Swap anchors and spans for disabled/enabled state on mobile controls
  function setMobileControlState(div, anchorId, iconHTML, disabled) {
    if (!div) return;
    const existingAnchor = div.querySelector('a#' + anchorId);
    const existingSpan = div.querySelector('span');
    if (disabled) {
      div.classList.add('disabled');
      if (existingAnchor) {
        const span = document.createElement('span');
        span.innerHTML = iconHTML || existingAnchor.innerHTML;
        existingAnchor.replaceWith(span);
      }
    } else {
      div.classList.remove('disabled');
      if (!existingAnchor) {
        const a = document.createElement('a');
        a.id = anchorId;
        a.href = '#';
        a.innerHTML = iconHTML || (existingSpan ? existingSpan.innerHTML : '');
        if (existingSpan) {
          existingSpan.replaceWith(a);
        } else {
          div.appendChild(a);
        }
      }
    }
  }

  // Create a page <div> for mobile pagination
  function createPageDiv(pageNum) {
    const div = document.createElement('div');
    div.className = 'pages' + (pageNum === currentPage ? ' current' : '');
    if (pageNum === currentPage) {
      const span = document.createElement('span');
      span.textContent = pageNum;
      div.appendChild(span);
    } else {
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = pageNum;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        currentPage = pageNum;
        renderPublications();
      });
      div.appendChild(a);
    }
    return div;
  }

  // Create dots for mobile pagination
  function createDotsDiv() {
    const div = document.createElement('div');
    div.className = 'pages current';
    const span = document.createElement('span');
    span.className = 'dots';
    span.textContent = '...';
    div.appendChild(span);
    return div;
  }

  // Create a page <li> matching partial pagination styles
  function createPageLi(pageNum) {
    const li = document.createElement('li');
    li.className = 'pages' + (pageNum === currentPage ? ' current' : '');
    if (pageNum === currentPage) {
      const span = document.createElement('span');
      span.textContent = pageNum;
      li.appendChild(span);
    } else {
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = pageNum;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        currentPage = pageNum;
        renderPublications();
      });
      li.appendChild(a);
    }
    return li;
  }

  // Add ellipsis
  function createDotsLi() {
    const li = document.createElement('li');
    li.className = 'pages current';
    const span = document.createElement('span');
    span.className = 'dots';
    span.textContent = '...';
    li.appendChild(span);
    return li;
  }

  // Clear all filters
  function clearFilters() {
    searchInput.value = '';
    typeFilter.value = '';
    yearFilter.value = '';
    itemsPerPageSelect.value = '12';
    itemsPerPage = 12;
    filterPublications();
  }

  // Event listeners
  searchInput.addEventListener('input', debounce(filterPublications, 300));
  typeFilter.addEventListener('change', filterPublications);
  yearFilter.addEventListener('change', filterPublications);
  
  itemsPerPageSelect.addEventListener('change', (e) => {
    itemsPerPage = parseInt(e.target.value);
    currentPage = 1;
    renderPublications();
  });
  
  clearFiltersBtn.addEventListener('click', clearFilters);
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', () => {
      filterPublications();
      // Optionally scroll to results
      const gridTop = publicationsGrid?.getBoundingClientRect().top + window.scrollY - 100;
      if (!isNaN(gridTop)) {
        window.scrollTo({ top: gridTop, behavior: 'smooth' });
      }
    });
  }
  
  prevPageBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage > 1) {
      currentPage--;
      renderPublications();
    }
  });
  
  nextPageBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
    if (currentPage < totalPages) {
      currentPage++;
      renderPublications();
    }
  });

  if (firstPageBtn) {
    firstPageBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (currentPage !== 1) {
        currentPage = 1;
        renderPublications();
      }
    });
  }

  if (lastPageBtn) {
    lastPageBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const totalPages = Math.ceil(filteredPublications.length / itemsPerPage);
      if (totalPages > 0 && currentPage !== totalPages) {
        currentPage = totalPages;
        renderPublications();
      }
    });
  }

  // Debounce function for search input
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Initialize
  initYearFilter();
  renderPublications();
}

// Initialize home redirect form functionality
function initHomeRedirectForm() {
  const form = document.getElementById('home-redirect-form');
  if (!form) return;

  const firstSelect = document.getElementById('first-select');
  const secondSelect = document.getElementById('second-select');
  const secondSelectGroup = document.getElementById('second-select-group');
  const secondLabel = document.getElementById('second-label');
  const secondOverlay = document.getElementById('second-overlay');
  const submitButton = document.getElementById('submit-button');
  const submitOverlay = document.getElementById('submit-overlay');
  const formDataScript = document.getElementById('home-form-data');

  if (!firstSelect || !secondSelect || !formDataScript) return;

  let formData;
  try {
    formData = JSON.parse(formDataScript.textContent);
  } catch (e) {
    console.error('Failed to parse home form data:', e);
    return;
  }

  // Handle first select change
  firstSelect.addEventListener('change', handleFirstSelectChange);
  
  // Handle second select change
  secondSelect.addEventListener('change', handleSecondSelectChange);
  
  // Handle form submission
  form.addEventListener('submit', handleFormSubmit);

  function handleFirstSelectChange(event) {
    const selectedIndex = parseInt(event.target.value);
    
    // Reset second select
    secondSelect.innerHTML = '<option value="">Choose...</option>';
    secondSelect.disabled = true;
    submitButton.disabled = true;
    
    // Reset visual states
    updateSecondSelectState(false);
    updateSubmitButtonState(false);

    if (selectedIndex >= 0 && formData.options[selectedIndex]) {
      const secondOptions = formData.options[selectedIndex].secondOptions;
      
      if (secondOptions && secondOptions.length > 0) {
        // Populate second select
        secondOptions.forEach((option, index) => {
          const optionElement = document.createElement('option');
          optionElement.value = option.url;
          optionElement.textContent = option.label;
          secondSelect.appendChild(optionElement);
        });
        
        // Enable second select and update visual state
        secondSelect.disabled = false;
        updateSecondSelectState(true);
      }
    }
  }

  function handleSecondSelectChange(event) {
    if (event.target.value) {
      submitButton.disabled = false;
      updateSubmitButtonState(true);
    } else {
      submitButton.disabled = true;
      updateSubmitButtonState(false);
    }
  }
  
  // Visual state update functions
  function updateSecondSelectState(enabled) {
    if (enabled) {
      // Enable state
      if (secondLabel) {
        secondLabel.classList.remove('text-gray-400');
        secondLabel.classList.add('text-gray-900');
      }
      if (secondSelect) {
        secondSelect.classList.remove('bg-gray-50', 'text-gray-400', 'cursor-not-allowed', 'border-gray-200');
        secondSelect.classList.add('bg-white', 'text-gray-900', 'cursor-pointer', 'border-gray-300');
      }
      if (secondOverlay) {
        secondOverlay.classList.add('opacity-0');
        secondOverlay.classList.remove('opacity-100');
      }
    } else {
      // Disable state
      if (secondLabel) {
        secondLabel.classList.add('text-gray-400');
        secondLabel.classList.remove('text-gray-900');
      }
      if (secondSelect) {
        secondSelect.classList.add('bg-gray-50', 'text-gray-400', 'cursor-not-allowed', 'border-gray-200');
        secondSelect.classList.remove('bg-white', 'text-gray-900', 'cursor-pointer', 'border-gray-300');
      }
      if (secondOverlay) {
        secondOverlay.classList.remove('opacity-0');
        secondOverlay.classList.add('opacity-100');
      }
    }
  }
  
  function updateSubmitButtonState(enabled) {
    if (enabled) {
      // Enable state
      if (submitButton) {
        submitButton.classList.remove('bg-gray-300', 'text-gray-500');
        submitButton.classList.add('bg-primary', 'text-white', 'hover:bg-primary-dark');
      }
      if (submitOverlay) {
        submitOverlay.classList.add('opacity-0');
        submitOverlay.classList.remove('opacity-100');
      }
    } else {
      // Disable state
      if (submitButton) {
        submitButton.classList.add('bg-gray-300', 'text-gray-500');
        submitButton.classList.remove('bg-primary', 'text-white', 'hover:bg-primary-dark');
      }
      if (submitOverlay) {
        submitOverlay.classList.remove('opacity-0');
        submitOverlay.classList.add('opacity-100');
      }
    }
  }

  function handleFormSubmit(event) {
    event.preventDefault();
    
    const selectedUrl = secondSelect.value;
    if (selectedUrl) {
      window.location.href = selectedUrl;
    }
  }
}

// Initialize resource filter functionality
function initResourceFilter() {
  const resourceLoops = document.querySelectorAll('.resource-loop');
  
  resourceLoops.forEach(loop => {
    const filterButtons = loop.querySelectorAll('.filter-btn');
    
    if (!filterButtons.length) return;
    
    filterButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        
        const filterValue = this.dataset.filter;
        const filterType = this.dataset.filterType;
        const currentUrl = new URL(window.location.href);
        
        // Handle different filter types
        if (filterType) {
          // Update URL parameter for specific filter type
          if (filterValue) {
            currentUrl.searchParams.set(filterType, filterValue);
          } else {
            currentUrl.searchParams.delete(filterType);
          }
        } else {
          // Legacy support - assume resource_type if no filterType specified
          if (filterValue) {
            currentUrl.searchParams.set('resource_type', filterValue);
          } else {
            currentUrl.searchParams.delete('resource_type');
          }
        }
        
        // Reset pagination when filtering
        if (currentUrl.searchParams.has('paged')) {
          currentUrl.searchParams.delete('paged');
        }
        
        // Navigate to new URL
        window.location.href = currentUrl.toString();
      });
    });
  });
}

// Initialize search type toggle functionality
function initSearchTypeToggle() {
  // Prevent multiple initializations
  if (window.searchToggleInitialized) {
    return;
  }
  
  const searchToggle = document.getElementById('search-type-toggle');
  const searchForm = document.getElementById('main-search-form');
  const searchInput = document.getElementById('search-input');
  
  if (!searchToggle || !searchForm || !searchInput) {
    return;
  }
  
  // Mark as initialized
  window.searchToggleInitialized = true;
  
  // Get courses page URL from global variable set in template
  const coursesPageUrl = window.coursesPageUrl || '/courses/';
  
  // Restore toggle state from localStorage
  const savedToggleState = localStorage.getItem('searchToggleState') === 'true';
  searchToggle.checked = savedToggleState;
  
  // Apply initial state
  updateSearchMode();
  
  // Handle toggle change
  searchToggle.addEventListener('change', function() {
    // Save state to localStorage
    localStorage.setItem('searchToggleState', this.checked);
    updateSearchMode();
  });
  
  // Function to update search mode based on toggle state
  function updateSearchMode() {
    if (searchToggle.checked) {
      // Switch to courses search
      searchForm.action = coursesPageUrl;
      searchInput.name = 'search';
      searchInput.placeholder = 'Search courses...';
      
      // Update visual feedback
      searchForm.classList.add('courses-search-mode');
    } else {
      // Switch back to standard WP search
      searchForm.action = window.location.origin;
      searchInput.name = 's';
      searchInput.placeholder = '';
      
      // Remove visual feedback
      searchForm.classList.remove('courses-search-mode');
    }
  }
  
  // Handle form submission for courses search
  searchForm.addEventListener('submit', function(e) {
    if (searchToggle.checked) {
      // Always prevent default for courses search
      e.preventDefault();
      
      const searchTerm = searchInput.value.trim();
      if (searchTerm) {
        // Redirect to courses page with search parameter
        window.location.href = `${coursesPageUrl}?search=${encodeURIComponent(searchTerm)}`;
      } else {
        // If no search term, just go to courses page
        window.location.href = coursesPageUrl;
      }
    }
    // For standard search, let the form submit normally
  });
}

// Initialize courses blocks functionality
function initCoursesBlocks() {
  const coursesBlocks = document.querySelectorAll('.courses-block');
  
  coursesBlocks.forEach(block => {
    const blockId = block.id.replace('courses-block-', '');
    const configScript = document.getElementById(`courses-block-config-${blockId}`);
    
    if (!configScript) return;
    
    let config;
    try {
      config = JSON.parse(configScript.textContent);
    } catch (e) {
      console.error('Failed to parse courses block config:', e);
      return;
    }
    
    initSingleCoursesBlock(blockId, config);
  });
}

// Initialize a single courses block with admin-configured filters
function initSingleCoursesBlock(blockId, config) {
  const loadingDiv = document.getElementById(`courses-loading-${blockId}`);
  const coursesGrid = document.getElementById(`courses-grid-${blockId}`);
  const noResultsDiv = document.getElementById(`courses-no-results-${blockId}`);
  const paginationDiv = document.getElementById(`courses-pagination-${blockId}`);
  const paginationDesktop = document.getElementById(`courses-pagination-desktop-${blockId}`);
  const paginationMobileNav = document.getElementById(`courses-pagination-mobile-nav-${blockId}`);
  const paginationMobilePages = document.getElementById(`courses-pagination-mobile-pages-${blockId}`);
  
  let isLoading = false;
  let allFilteredCourses = [];
  let currentPage = 1;
  
  // Fetch and filter courses based on admin configuration
  async function fetchAndFilterCourses() {
    if (isLoading) return;
    
    isLoading = true;
    showLoading(true);
    
    try {
      let allCourses = [];
      
      // Fetch courses based on default display setting
      if (config.defaultDisplay === 'featured' || config.defaultDisplay === 'recent') {
        const response = await fetch('https://central.csds.qld.edu.au/api/v2/courses/fetch-landing', {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          },
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        switch (config.defaultDisplay) {
          case 'featured':
            allCourses = data.featuredCourses || [];
            break;
          case 'recent':
            allCourses = data.upcomingCourses || [];
            break;
        }
      } else {
        // Fetch all courses for comprehensive filtering
        allCourses = await fetchAllCoursesData();
      }
      
      // Apply admin-configured filters
      allFilteredCourses = applyAdminFilters(allCourses, config);
      
      // Reset to first page and display (no max results limit - pagination handles all results)
      currentPage = 1;
      displayCurrentPage();
      
    } catch (error) {
      console.error('Error fetching courses:', error);
      showError('Failed to load courses. Please try again later.');
    } finally {
      isLoading = false;
      showLoading(false);
    }
  }
  
  // Fetch all courses data with pagination handling
  async function fetchAllCoursesData() {
    let allCourses = [];
    let page = 1;
    const limit = 20;
    const maxPages = 100;
    
    // Try different pagination patterns like the PHP template does
    const paginationPatterns = [
      '?page={page}',
      '?page={page}&limit={limit}',
      '?page={page}&per_page={limit}',
      '?offset={offset}&limit={limit}',
      '?skip={offset}&take={limit}'
    ];
    
    for (const pattern of paginationPatterns) {
      allCourses = [];
      page = 1;
      let foundNewData = false;
      
      try {
        do {
          const offset = (page - 1) * limit;
          const currentUrl = 'https://central.csds.qld.edu.au/api/v2/courses' + pattern.replace(
            /{page}/g, page
          ).replace(
            /{limit}/g, limit
          ).replace(
            /{offset}/g, offset
          );
          
          const response = await fetch(currentUrl, {
            method: 'GET',
            headers: {
              'Accept': 'application/json',
            },
          });
          
          if (!response.ok) {
            break;
          }
          
          const pageData = await response.json();
          
          if (Array.isArray(pageData)) {
            const pageCount = pageData.length;
            
            if (page === 1) {
              allCourses = pageData;
            } else {
              // Check if we're getting new data or the same data repeated
              let isNewData = false;
              if (pageData.length > 0 && allCourses.length > 0) {
                const firstNewId = pageData[0].courseID;
                const existingIds = allCourses.map(course => course.courseID);
                isNewData = !existingIds.includes(firstNewId);
              }
              
              if (isNewData) {
                allCourses = allCourses.concat(pageData);
                foundNewData = true;
              } else {
                break;
              }
            }
            
            // If we got fewer items than expected, we've reached the end
            if (pageCount < limit) {
              break;
            }
          } else {
            break;
          }
          
          page++;
          
        } while (page <= maxPages);
        
        // If we found new data with this pattern, use it
        if (foundNewData && allCourses.length > 20) {
          return allCourses;
        }
        
      } catch (error) {
        continue;
      }
    }
    return allCourses;
  }
  
  // Apply admin-configured filters to courses
  function applyAdminFilters(courses, config) {
    let filtered = [...courses];
    
    // Apply search term filter - supports comma-separated terms
    if (config.searchTerm && config.searchTerm.trim()) {
      const searchInput = config.searchTerm.trim().toLowerCase();
      
      // Split by comma and clean up each term
      const searchTerms = searchInput.split(',').map(term => term.trim()).filter(term => term.length > 0);
      
      filtered = filtered.filter(course => {
        const searchableText = [
          course.courseName || '',
          course.courseCode || '',
          course.courseDescription || '',
          course.shortDescription || ''
        ].join(' ').toLowerCase();
        
        // Course matches if it contains ANY of the search terms
        return searchTerms.some(term => searchableText.includes(term));
      });
    }
    
    // Apply course type filters
    if (config.filterTypes && config.filterTypes.length > 0) {
      filtered = filtered.filter(course => {
        const isOnline = course.courseTypeID === 2 || course.courseClass === 'online';
        const isF2f = course.courseTypeID === 1 || course.courseClass === 'f2f';
        const isBlended = course.courseTypeID === 3;
        
        return (config.filterTypes.includes('online') && isOnline) ||
               (config.filterTypes.includes('f2f') && isF2f) ||
               (config.filterTypes.includes('blended') && isBlended);
      });
    }
    
    // Apply sorting
    if (config.sortBy && config.sortBy !== 'default') {
      filtered.sort((a, b) => {
        switch (config.sortBy) {
          case 'name':
            return (a.courseName || '').localeCompare(b.courseName || '');
          case 'name-desc':
            return (b.courseName || '').localeCompare(a.courseName || '');
          case 'duration':
            return (parseInt(a.courseDuration) || 0) - (parseInt(b.courseDuration) || 0);
          case 'duration-desc':
            return (parseInt(b.courseDuration) || 0) - (parseInt(a.courseDuration) || 0);
          default:
            return 0;
        }
      });
    }
    
    return filtered;
  }
  
  // Show/hide loading state
  function showLoading(show) {
    if (loadingDiv) {
      loadingDiv.classList.toggle('hidden', !show);
    }
    if (coursesGrid) {
      coursesGrid.classList.toggle('hidden', show);
    }
  }
  
  // Show error message
  function showError(message) {
    if (coursesGrid) {
      coursesGrid.innerHTML = `
        <div class="col-span-full text-center py-8">
          <p class="text-red-600">${message}</p>
        </div>
      `;
    }
  }
  
  // Display current page of courses
  function displayCurrentPage() {
    if (!coursesGrid) return;
    
    // Hide loading
    showLoading(false);
    
    if (allFilteredCourses.length === 0) {
      // Show no results
      if (noResultsDiv) noResultsDiv.classList.remove('hidden');
      if (paginationDiv) paginationDiv.classList.add('hidden');
      coursesGrid.classList.add('hidden');
      return;
    }
    
    // Hide no results and show grid
    if (noResultsDiv) noResultsDiv.classList.add('hidden');
    coursesGrid.classList.remove('hidden');
    
    // Calculate pagination
    const coursesPerPage = config.postsPerPage || 12;
    const totalCourses = allFilteredCourses.length;
    const totalPages = Math.ceil(totalCourses / coursesPerPage);
    const startIndex = (currentPage - 1) * coursesPerPage;
    const endIndex = Math.min(startIndex + coursesPerPage, totalCourses);
    const currentPageCourses = allFilteredCourses.slice(startIndex, endIndex);
    
    // Display courses for current page
    coursesGrid.innerHTML = currentPageCourses.map(course => createCourseCard(course, config.courseUrl)).join('');
    
    // Show/hide pagination
    if (totalPages > 1) {
      if (paginationDiv) paginationDiv.classList.remove('hidden');
      updatePaginationControls(currentPage, totalPages);
    } else {
      if (paginationDiv) paginationDiv.classList.add('hidden');
    }
  }
  
  // Update pagination controls to match existing pagination.twig structure
  function updatePaginationControls(page, totalPages) {
    // Generate pagination HTML for desktop
    if (paginationDesktop) {
      paginationDesktop.innerHTML = generateDesktopPagination(page, totalPages);
    }
    
    // Generate pagination HTML for mobile navigation
    if (paginationMobileNav) {
      paginationMobileNav.innerHTML = generateMobileNavigation(page, totalPages);
    }
    
    // Generate pagination HTML for mobile page numbers
    if (paginationMobilePages) {
      paginationMobilePages.innerHTML = generateMobilePages(page, totalPages);
    }
  }
  
  // Navigate to specific page
  function goToPage(page) {
    const totalPages = Math.ceil(allFilteredCourses.length / (config.postsPerPage || 12));
    if (page >= 1 && page <= totalPages) {
      currentPage = page;
      displayCurrentPage();
    }
  }
  
  // Make goToPage globally accessible for onclick handlers
  window[`goToPage_${blockId}`] = goToPage;
  
  // SVG icons matching the existing pagination
  const firstPageIcon = '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="M240-240v-480h80v480h-80Zm440 0L440-480l240-240 56 56-184 184 184 184-56 56Z"/></svg>';
  const previousPageIcon = '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z"/></svg>';
  const lastPageIcon = '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="m280-240-56-56 184-184-184-184 56-56 240 240-240 240Zm360 0v-480h80v480h-80Z"/></svg>';
  const nextPageIcon = '<svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor"><path d="M504-480 320-664l56-56 240 240-240 240-56-56 184-184Z"/></svg>';
  
  // Generate desktop pagination (all controls in one row)
  function generateDesktopPagination(currentPage, totalPages) {
    let html = '';
    
    // First button
    if (currentPage > 1) {
      html += `<div class="first"><a onclick="window.goToPage_${blockId}(1)">${firstPageIcon}</a></div>`;
    } else {
      html += `<div class="first disabled"><span>${firstPageIcon}</span></div>`;
    }
    
    // Previous button
    if (currentPage > 1) {
      html += `<div class="prev"><a onclick="window.goToPage_${blockId}(${currentPage - 1})">${previousPageIcon}</a></div>`;
    } else {
      html += `<div class="prev disabled"><span>${previousPageIcon}</span></div>`;
    }
    
    // Page numbers
    html += generatePageNumbers(currentPage, totalPages);
    
    // Next button
    if (currentPage < totalPages) {
      html += `<div class="next"><a onclick="window.goToPage_${blockId}(${currentPage + 1})">${nextPageIcon}</a></div>`;
    } else {
      html += `<div class="next disabled"><span>${nextPageIcon}</span></div>`;
    }
    
    // Last button
    if (currentPage < totalPages) {
      html += `<div class="last"><a onclick="window.goToPage_${blockId}(${totalPages})">${lastPageIcon}</a></div>`;
    } else {
      html += `<div class="last disabled"><span>${lastPageIcon}</span></div>`;
    }
    
    return html;
  }
  
  // Generate mobile navigation (first, prev, next, last)
  function generateMobileNavigation(currentPage, totalPages) {
    let html = '';
    
    // First button
    if (currentPage > 1) {
      html += `<div class="first"><a onclick="window.goToPage_${blockId}(1)">${firstPageIcon}</a></div>`;
    } else {
      html += `<div class="first disabled"><span>${firstPageIcon}</span></div>`;
    }
    
    // Previous button
    if (currentPage > 1) {
      html += `<div class="prev"><a onclick="window.goToPage_${blockId}(${currentPage - 1})">${previousPageIcon}</a></div>`;
    } else {
      html += `<div class="prev disabled"><span>${previousPageIcon}</span></div>`;
    }
    
    // Next button
    if (currentPage < totalPages) {
      html += `<div class="next"><a onclick="window.goToPage_${blockId}(${currentPage + 1})">${nextPageIcon}</a></div>`;
    } else {
      html += `<div class="next disabled"><span>${nextPageIcon}</span></div>`;
    }
    
    // Last button
    if (currentPage < totalPages) {
      html += `<div class="last"><a onclick="window.goToPage_${blockId}(${totalPages})">${lastPageIcon}</a></div>`;
    } else {
      html += `<div class="last disabled"><span>${lastPageIcon}</span></div>`;
    }
    
    return html;
  }
  
  // Generate mobile page numbers
  function generateMobilePages(currentPage, totalPages) {
    return generatePageNumbers(currentPage, totalPages);
  }
  
  // Generate page numbers (shared between desktop and mobile)
  function generatePageNumbers(currentPage, totalPages) {
    let html = '';
    
    for (let i = 1; i <= totalPages; i++) {
      if (i === currentPage) {
        html += `<div class="pages current"><span>${i}</span></div>`;
      } else {
        html += `<div class="pages"><a onclick="window.goToPage_${blockId}(${i})">${i}</a></div>`;
      }
    }
    
    return html;
  }
  
  // Create individual course card HTML matching tease-courseAll.twig
  function createCourseCard(course, courseUrl) {
    const imageUrl = course.courseImageURL || '';
    const courseName = course.courseName || 'Untitled Course';
    const description = course.shortDescription || course.courseDescription || '';
    const truncatedDescription = description.length > 80 ? description.substring(0, 80) + '...' : description;
    const courseClass = course.courseClass || '';
    const courseId = course.courseID || '';
    const courseTypeName = course.type?.courseTypeName || '';
    const courseDuration = course.courseDuration || '';
    const durationMeasurement = course.courseDurationMeasurement || '';
    
    // Format duration text
    let durationText = '';
    if (courseDuration) {
      if (durationMeasurement === 'H') {
        durationText = `${courseDuration} ${courseDuration != 1 ? 'Hours' : 'Hour'}`;
      } else if (durationMeasurement === 'D') {
        durationText = `${courseDuration} ${courseDuration != 1 ? 'Days' : 'Day'}`;
      } else if (durationMeasurement === 'W') {
        durationText = `${courseDuration} ${courseDuration != 1 ? 'Weeks' : 'Week'}`;
      } else {
        durationText = courseDuration;
      }
    }
    
    return `
      <div class="block h-full">
        <article class="tease rounded-2xl border-gray-400 border border-solid h-full overflow-hidden flex flex-col h-full group">
          ${imageUrl ? `
            <div class="rounded-br-3xl overflow-hidden relative teal-duotone">
              ${courseClass === 'online' ? `
                <p class="m-0 text-xs absolute bottom-6 left-6 z-10 uppercase bg-primary rounded-full text-light px-2">${courseClass}</p>
              ` : ''}
              <a href="${courseUrl}/${courseId}" target="_blank" class="">
                <img class="object-cover h-44 w-full object-center group-hover:scale-105 transition duration-300 ease-in-out" src="${imageUrl}"/>
              </a>
            </div>
          ` : ''}
          <div class="p-6 flex flex-col justify-between grow">
            <div class="grow">
              <a href="${courseUrl}/${courseId}" target="_blank" class="flex">
                <h2 class="mt-0 text-lg my-6 !leading-snug text-primary group-hover:text-primary-light transition-colors duration-100 ease-in-out mr-2">
                  ${courseName}
                </h2>
              </a>
              <p class="mt-0">${truncatedDescription}</p>
            </div>
            <div class="mt-2 flex items-center justify-between">
              ${courseTypeName ? `
                <p class="m-0 text-xs uppercase bg-primary rounded-full text-light px-2">${courseTypeName}</p>
              ` : ''}
              ${durationText ? `
                <p class="m-0 text-xs uppercase bg-gray-100 rounded-md text-dark px-2">${durationText}</p>
              ` : ''}
            </div>
          </div>
        </article>
      </div>
    `;
  }
  
  // Initialize the block
  fetchAndFilterCourses();
}

// Initialize back to top button functionality
function initBackToTop() {
  const backToTopButton = document.getElementById('back-to-top');
  
  if (!backToTopButton) return;
  
  // Show/hide button based on scroll position
  function toggleBackToTopButton() {
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
    const viewportHeight = window.innerHeight;
    
    if (scrollPosition > viewportHeight) {
      backToTopButton.classList.add('visible');
    } else {
      backToTopButton.classList.remove('visible');
    }
  }
  
  // Smooth scroll to top when button is clicked
  function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }
  
  // Add event listeners
  window.addEventListener('scroll', toggleBackToTopButton);
  backToTopButton.addEventListener('click', scrollToTop);
  
  // Initial check in case page is already scrolled
  toggleBackToTopButton();
}

// Initialize everything on window load
window.addEventListener("load", () => {
  initAccordion();
  initMobileMenu();
  initSidebarMenu();
  handleSubmenuToggle();
  initTabs();
  initContentSlider();
  initStarRating();
  initCourseFiltering();
  initPublicationsFiltering();
  initSearchTypeToggle();
  initResourceFilter();
  initBackToTop();
  initCoursesBlocks();

  // Reapply submenu toggle on window resize
  window.addEventListener("resize", handleSubmenuToggle);

  // Setup observer to watch for dynamically added content
  setupMutationObserver();

  // Initialize home redirect form
  initHomeRedirectForm();
});
