<?php

acf_add_local_field_group([
    'key' => 'group_custom_post_loop',
    'title' => 'Custom Post Loop Settings',
    'fields' => [
        [
            'key' => 'field_post_type',
            'label' => 'Post Type',
            'name' => 'post_type',
            'type' => 'select',
            'instructions' => 'Select which post type to display',
            'required' => 1,
            'choices' => [],
            'default_value' => 'post',
            'return_format' => 'value',
            'multiple' => 0,
            'ui' => 1,
        ],
        [
            'key' => 'field_posts_per_page',
            'label' => 'Posts Per Page',
            'name' => 'posts_per_page',
            'type' => 'number',
            'instructions' => 'Enter the number of posts to display',
            'required' => 1,
            'default_value' => 6,
            'min' => 3,
            'max' => 12,
        ],
        [
            'key' => 'field_posts_offset',
            'label' => 'Posts Offset',
            'name' => 'posts_offset',
            'type' => 'number',
            'instructions' => 'Skip this many posts from the beginning (0 = start from first post)',
            'required' => 0,
            'default_value' => 0,
            'min' => 0,
            'max' => 100,
        ],
        [
            'key' => 'field_alternate_layout',
            'label' => 'Alternate Layout',
            'name' => 'alternate_layout',
            'type' => 'true_false',
            'instructions' => 'Enable to use an alternate layout for the list',
            'default_value' => 0,
            'ui' => 1,
            'ui_on_text' => 'On',
            'ui_off_text' => 'Off',
        ],
        [
            'key' => 'field_minimal_layout',
            'label' => 'Minimal Layout',
            'name' => 'minimal_layout',
            'type' => 'true_false',
            'instructions' => 'Enable to use a minimal presentation (reduced metadata/styling)',
            'default_value' => 0,
            'ui' => 1,
            'ui_on_text' => 'On',
            'ui_off_text' => 'Off',
        ],
        [
            'key' => 'field_show_more_button',
            'label' => 'Show "More Posts" Button',
            'name' => 'show_more_button',
            'type' => 'true_false',
            'instructions' => 'Enable to display a "More Posts" button at the bottom',
            'default_value' => 1,
            'ui' => 1,
        ],
        [
            'key' => 'field_button_text',
            'label' => 'Button Text',
            'name' => 'button_text',
            'type' => 'link',
            'instructions' => 'Enter the text and link for the "More Posts" button',
            'required' => 0,
            'conditional_logic' => [
                [
                    [
                        'field' => 'field_show_more_button',
                        'operator' => '==',
                        'value' => '1',
                    ]
                ]
            ],
            'return_format' => 'array',
        ],
    ],
    'location' => [
        [
            [
                'param' => 'block',
                'operator' => '==',
                'value' => 'acf/custom-post-loop',
            ],
        ],
    ],
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
]);

// Populate post type choices dynamically
add_filter('acf/load_field/name=post_type', function($field) {
    $post_types = get_post_types(['public' => true], 'objects');
    $choices = [];
    
    foreach ($post_types as $post_type) {
        // Skip attachment
        if ($post_type->name === 'attachment') {
            continue;
        }
        
        // Include all public post types except attachment
        $choices[$post_type->name] = $post_type->labels->singular_name;
    }
    
    $field['choices'] = $choices;
    return $field;
});