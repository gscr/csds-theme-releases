<?php
// Register ACF field group for Custom Container Block
acf_add_local_field_group(
    array(
        'key' => 'group_custom_container_block',
        'title' => 'Custom Container Block Fields',
        'fields' => array(
            array(
                'key' => 'st_tab_general',
                'label' => 'General',
                'type' => 'tab',
            ),
            array(
                'key' => 'st_container_background_color',
                'label' => 'Background Colour',
                'name' => 'container_background_color_radio',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_container_text_color',
                'label' => 'Text Colour',
                'name' => 'container_text_color',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_container_border_color',
                'label' => 'Border Colour',
                'name' => 'container_border_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-200' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_container_border_top_color',
                'label' => 'Border Top Colour',
                'name' => 'container_border_top_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-200' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_container_border_left_color',
                'label' => 'Border Left Colour',
                'name' => 'container_border_left_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-200' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_container_padding',
                'label' => 'Container padding',
                'name' => 'container_padding',
                'type' => 'radio',
                'choices' => array(
                    '0' => 'None',
                    '4' => 'Small',
                    '8' => 'Medium',
                    '16' => 'Large',
                    '24' => 'XL',
                ),
                'wrapper' => array(
                    'class' => 'st-padding-picker',
                ),
            ),
            array(
                'key' => 'st_container_max_width',
                'label' => 'Container max width',
                'name' => 'container_max_width',
                'type' => 'radio',
                'choices' => array(
                    'none' => 'None',
                    '7xl' => '7xl',
                    '6xl' => '6xl',
                    '5xl' => '5xl',
                    '4xl' => '4xl',
                ),
                'wrapper' => array(
                    'class' => 'st-max-width-picker',
                ),
            ),
            array(
                'key' => 'st_container_shadow',
                'label' => 'Shadow',
                'name' => 'container_shadow',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_container_rounded',
                'label' => 'Rounded corners',
                'name' => 'container_rounded',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_container_rounded_br',
                'label' => 'Large rounded bottom right corner',
                'name' => 'container_rounded_br',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
            ),
            array(
                'key' => 'st_container_internal_styling',
                'label' => 'Internal styling',
                'name' => 'container_internal_styling',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
                'instructions' => 'This will add some specific styling when this container it is nested inside another container. This is useful when being used as a lead image or block inside a card element.',
            ),
            array(
                'key' => 'st_tab_hover',
                'label' => 'Hover',
                'type' => 'tab',
            ),
            array(
                'key' => 'st_container_hover',
                'label' => 'Hover',
                'name' => 'container_hover',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
                'instructions' => 'Enable or disable hover effect for the container.',
            ),
            array(
                'key' => 'st_container_background_hover_color',
                'label' => 'Background Hover Colour',
                'name' => 'container_background_hover_color_radio',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_hover',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_container_text_hover_color',
                'label' => 'Text Hover Colour',
                'name' => 'container_text_hover_color',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_hover',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_container_border_hover_color',
                'label' => 'Border Hover Colour',
                'name' => 'container_border_hover_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-200' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_hover',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_container_border_top_hover_color',
                'label' => 'Border Top Hover Colour',
                'name' => 'container_border_top_hover_color',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-200' => '',
                ),
                'default_value' => 'transparent',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_hover',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_tab_link',
                'label' => 'Link',
                'type' => 'tab',
            ),
            array(
                'key' => 'st_container_show_link',
                'label' => 'Link',
                'name' => 'container_show_link',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'On',
                'ui_off_text' => 'Off',
                'instructions' => 'Add a link to the container.',
            ),
            array(
                'key' => 'st_container_link',
                'label' => 'Container Link',
                'name' => 'container_link',
                'type' => 'link',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_show_link',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_container_show_arrow',
                'label' => 'Arrow',
                'name' => 'container_show_arrow',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'Show',
                'ui_off_text' => 'Hide',
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_container_show_link',
                            'operator' => '==',
                            'value' => '1',
                        ),
                    ),
                ),
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/custom-container',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=container_background_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_text_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_border_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_border_top_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_border_left_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_background_hover_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_text_hover_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_border_hover_color', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=container_border_top_hover_color', 'wd_acf_dynamic_colors_load');