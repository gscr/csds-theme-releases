<?php
/**
 * Template Name: Research
 * Description: A Page Template for research that shows publications.
 */

namespace App;

use Timber\Timber;

$context = Timber::context();

// Query the custom post type 'publication'
$args = array(
    'post_type' => 'publication',
    'posts_per_page' => -1, 
    'meta_key' => 'year', 
    'orderby' => 'meta_value_num', 
    'order' => 'ASC', 
);
$publications = Timber::get_posts($args);

// Get the taxonomy terms for each publication
foreach ($publications as $publication) {
    $publication->terms = Timber::get_terms([
        'taxonomy' => 'publication_type',
        'object_ids' => $publication->ID,
    ]);
}

$context['publications'] = $publications;

Timber::render('templates/page-research.twig', $context);
