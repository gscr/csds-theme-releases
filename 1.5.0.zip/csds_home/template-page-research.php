<?php
/**
 * Template Name: Research
 * Description: A Page Template for research that shows publications.
 */

namespace App;

use Timber\Timber;

$context = Timber::context();

// Query the custom post type 'publication'
$args = array(
    'post_type' => 'publication',
    'posts_per_page' => -1, 
    'meta_key' => 'year', 
    'orderby' => 'meta_value_num', 
    'order' => 'DESC', 
);
$publications = Timber::get_posts($args);

// $context['publications'] = $publications;
$grouped_publications = [];
foreach ($publications as $publication) {
    $terms = wp_get_post_terms($publication->ID, 'publication_type');
    foreach ($terms as $term) {
        if (!isset($grouped_publications[$term->slug])) {
            $grouped_publications[$term->slug] = [
                'term' => $term,
                'publications' => []
            ];
        }
        $grouped_publications[$term->slug]['publications'][] = $publication;
    }
}

$context['grouped_publications'] = $grouped_publications;

// Prepare all publications data for JavaScript
$all_publications_data = [];
foreach ($publications as $publication) {
    $terms = wp_get_post_terms($publication->ID, 'publication_type');
    $term_names = array_map(function($term) { return $term->name; }, $terms);
    $term_slugs = array_map(function($term) { return $term->slug; }, $terms);
    
    $all_publications_data[] = [
        'id' => $publication->ID,
        'title' => $publication->meta('title'),
        'details' => $publication->meta('details'),
        'year' => $publication->meta('year'),
        'link' => $publication->meta('link')->url ?? '',
        'terms' => $terms,
        'term_names' => $term_names,
        'term_slugs' => $term_slugs,
        'post' => $publication
    ];
}

$context['all_publications_json'] = json_encode($all_publications_data);

// Get all unique publication types for filter
$all_terms = get_terms([
    'taxonomy' => 'publication_type',
    'hide_empty' => true
]);
$context['publication_types'] = $all_terms;

Timber::render('templates/page-research.twig', $context);
