<?php
/**
 * Search results with filters
 */

namespace App;

use Timber\Timber;

// Collect search term
$search = get_search_query();

// Get searchable post types from customizer settings
$searchable_post_types = get_searchable_post_types();

// Gather all public post types (exclude attachments) for filter options
$post_type_objects = get_post_types(['public' => true], 'objects');
unset($post_type_objects['attachment']);

// Build options map slug => label, but only include searchable post types
$post_type_options = [];
foreach ($post_type_objects as $slug => $obj) {
    // Only include post types that are allowed by customizer settings
    if (in_array($slug, $searchable_post_types)) {
        $post_type_options[$slug] = $obj->labels->singular_name ?: $obj->label ?: ucfirst($slug);
    }
}

// Selected types from query (?type[]=page&type[]=post), default to customizer settings if none provided
$selected_types = isset($_GET['type']) ? (array) $_GET['type'] : $searchable_post_types;
$selected_types = array_values(array_intersect(array_keys($post_type_options), array_map('sanitize_text_field', $selected_types)));
if (empty($selected_types)) {
    $selected_types = $searchable_post_types;
}

$paged = max(1, (int) get_query_var('paged'));
$per_page = (int) get_query_var('posts_per_page');
if ($per_page <= 0) {
    $per_page = (int) get_option('posts_per_page');
}

// Build the query
$query_args = [
    's' => $search,
    'post_type' => $selected_types,
    'posts_per_page' => $per_page,
    'paged' => $paged,
    'post_status' => 'publish',
];

$wp_query = new \WP_Query($query_args);

$context = Timber::context();
$context['search_query'] = $search;
$context['posts'] = Timber::get_posts($wp_query);
$context['pagination'] = Timber::get_pagination([], $wp_query);
$context['post_type_options'] = $post_type_options;
$context['selected_types'] = $selected_types;

Timber::render('templates/search.twig', $context);
