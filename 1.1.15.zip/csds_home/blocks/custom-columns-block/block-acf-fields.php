<?php
// https://whiteleydesigns.com/acf-gutenberg-color-picker/
// https://whiteleydesigns.com/styled-advanced-custom-fields-radio-buttons/

acf_add_local_field_group(
    array(
        'key' => 'group_custom_columns_block',
        'title' => 'Custom Columns Block Fields',
        'fields' => array(
            array(
                'key' => 'st_columns_desktop',
                'label' => 'Number of Columns (Desktop)',
                'name' => 'columns_desktop',
                'type' => 'radio',
                'choices' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ),
                'wrapper' => array(
                    'class' => 'st-column-picker',
                ),
            ),
            array(
                'key' => 'st_two_col_layout',
                'label' => 'Two Column Layout',
                'name' => 'two_col_layout',
                'type' => 'radio',
                'choices' => array(
                    'left-xs' => 'Left xs',
                    'left-sm' => 'Left sm',
                    '2' => 'Even',
                    'right-sm' => 'Right sm',
                    'right-xs' => 'Right xs',
                ),
                'default_value' => '2',
                'wrapper' => array(
                    'class' => 'st-two-col-layout',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_columns_desktop',
                            'operator' => '==',
                            'value' => '2',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_three_col_layout',
                'label' => 'Three Column Layout',
                'name' => 'three_col_layout',
                'type' => 'radio',
                'choices' => array(
                    '3' => 'Even',
                    'left-focus' => 'Left lg',
                    'center-focus' => 'Center lg',
                    'right-focus' => 'Right lg',
                ),
                'default_value' => '3',
                'wrapper' => array(
                    'class' => 'st-three-col-layout',
                ),
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'st_columns_desktop',
                            'operator' => '==',
                            'value' => '3',
                        ),
                    ),
                ),
            ),
            array(
                'key' => 'st_columns_mobile',
                'label' => 'Number of Columns (Mobile)',
                'name' => 'columns_mobile',
                'type' => 'radio',
                'choices' => array(
                    '1' => '1',
                    '2' => '2',
                ),
                'wrapper' => array(
                    'class' => 'st-column-picker',
                ),
            ),
            array(
                'key' => 'st_columns_gap',
                'label' => 'Column Gap',
                'name' => 'columns_gap',
                'type' => 'radio',
                'choices' => array(
                    '8' => 'Small',
                    '16' => 'Medium',
                    '24' => 'Large',
                ),
                'wrapper' => array(
                    'class' => 'st-gap-picker',
                ),
            ),
            array(
                'key' => 'st_columns_padding',
                'label' => 'Container padding',
                'name' => 'columns_padding',
                'type' => 'radio',
                'choices' => array(
                    '0' => 'None',
                    '4' => 'Small',
                    '8' => 'Medium',
                    '16' => 'Large',
                    '24' => 'XL',
                ),
                'wrapper' => array(
                    'class' => 'st-padding-picker',
                ),
            ),
            array(
                'key' => 'st_columns_background_color_radio',
                'label' => 'Background Color',
                'name' => 'columns_background_color_radio',
                'type' => 'radio',
                'choices' => array(
                    'transparent' => '',
                    'gray-50' => '',
                ),
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_columns_text_color_radio',
                'label' => 'Text Color',
                'name' => 'columns_text_color_radio',
                'type' => 'radio',
                'choices' => array(
                ),
                'default_value' => 'dark',
                'wrapper' => array(
                    'class' => 'st-colour-picker',
                ),
            ),
            array(
                'key' => 'st_columns_include_background_video',
                'label' => 'Moving gradient',
                'name' => 'columns_background_video',
                'type' => 'true_false',
                'instructions' => 'Show the csds moving gradient',
                'default_value' => 0,
                'ui' => 1,
                'ui_on_text' => 'Yes',
                'ui_off_text' => 'No',
            ),
            array(
                'key' => 'st_columns_equal_height',
                'label' => 'Equalise Column Height',
                'name' => 'equal_height',
                'type' => 'true_false',
                'ui' => 1,
                'ui_on_text' => 'Yes',
                'ui_off_text' => 'No',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'block',
                    'operator' => '==',
                    'value' => 'acf/custom-columns-block',
                ),
            ),
        ),
    )
);

add_filter('acf/load_field/name=columns_background_color_radio', 'wd_acf_dynamic_colors_load');
add_filter('acf/load_field/name=columns_text_color_radio', 'wd_acf_dynamic_colors_load');