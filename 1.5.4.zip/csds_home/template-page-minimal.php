<?php
/**
 * Template Name: Minimal Content Only
 * Description: A minimal page template that displays only Gutenberg content without header, footer, or any other theme elements.
 */

namespace App;

use Timber\Timber;

$context = Timber::context();

Timber::render([
    'templates/page-minimal.twig'
], $context);
